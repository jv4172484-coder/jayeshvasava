import React, { useState, useEffect, useRef } from 'react';
import { 
  ArrowRight, 
  ExternalLink, 
  Menu, 
  X, 
  Linkedin, 
  Github, 
  Instagram, 
  Check, 
  ChevronRight, 
  Mail,
  Smartphone,
  Sparkles,
  Award,
  Clock,
  Layers,
  Wrench,
  MessageSquare,
  Globe,
  Terminal,
  MousePointerClick
} from 'lucide-react';
import { 
  PORTFOLIO_PROJECTS, 
  CORE_SERVICES, 
  TECH_STOCKS_CATEGORIES, 
  EXPERTISE_SKILLS 
} from './data';
import WorkspaceVisuals from './components/WorkspaceVisuals';
import ProceduralPattern from './components/ProceduralPattern';
import CognitiveTerminal from './components/CognitiveTerminal';
import BrandedLinkHub from './components/BrandedLinkHub';

export default function App() {
  // 1. Loading state & simulation
  const [loading, setLoading] = useState(true);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [loadingLogs, setLoadingLogs] = useState<string[]>([]);
  
  // 2. Custom Cursor tracking state
  const [cursorPos, setCursorPos] = useState({ x: -100, y: -100 });
  const cursorTargetPos = useRef({ x: -100, y: -100 });
  const [cursorHover, setCursorHover] = useState(false);
  const [cursorType, setCursorType] = useState<'default' | 'text' | 'view'>('default');
  const [isTouchDevice, setIsTouchDevice] = useState(false);

  // 3. Navigation and Scroll triggers
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');

  // 4. Cognitive Terminal toggle
  const [isTerminalOpen, setIsTerminalOpen] = useState(false);

  // 5. Contact Form state
  const [formType, setFormType] = useState<string>('UI/UX Design');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    budget: '$5k - $10k',
    message: ''
  });
  const [formFocused, setFormFocused] = useState<Record<string, boolean>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // 6. Project filter / tracking (horizontal gallery)
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
  const [scrollProgress, setScrollProgress] = useState(0);

  // 7. Stat counters state
  const [stats, setStats] = useState({ projects: 0, disciplines: 0, tools: 0, lighthouse: 0 });
  const statsSectionRef = useRef<HTMLDivElement | null>(null);
  const [hasAnimatedStats, setHasAnimatedStats] = useState(false);

  // 8. Services tilt angle trackers
  const [cardTilts, setCardTilts] = useState<Record<string, { rx: number; ry: number; mx: number; my: number }>>({});

  // Detect touch capability to skip cursors
  useEffect(() => {
    const isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    setIsTouchDevice(isTouch);
  }, []);

  // First Paint loader simulation
  useEffect(() => {
    const logs = [
      "SYSTEM_BOOTSTRAP_COMPLETE",
      "FETCH_PORTFOLIO_INDEX_2024_2025",
      "COORDINATE_COGNITIVE_AI_SYNAPSE",
      "COMPILE_PROCEDURAL_WEBGL_ASSETS",
      "ENGAGE_INDUSTRIAL_GRID_LOCK",
      "LAUNCH_PREMIUM_STUDIO_WORKSPACE"
    ];

    let logCounter = 0;
    const logInterval = setInterval(() => {
      if (logCounter < logs.length) {
        setLoadingLogs(prev => [...prev, `[INIT_LOGS] ${logs[logCounter]} ... OK`]);
        logCounter++;
      }
    }, 250);

    const timer = setInterval(() => {
      setLoadingProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          clearInterval(logInterval);
          setTimeout(() => setLoading(false), 400); // Small fade out delay
          return 100;
        }
        // Accelerate loading progress slightly over time
        return prev + Math.floor(Math.random() * 8) + 4;
      });
    }, 60);

    return () => {
      clearInterval(timer);
      clearInterval(logInterval);
    };
  }, []);

  // Lerping cursor positions
  useEffect(() => {
    if (isTouchDevice) return;

    const handleMouseMove = (e: MouseEvent) => {
      cursorTargetPos.current = { x: e.clientX, y: e.clientY };
      
      // Determine context style based on DOM node being hovered
      const target = e.target as HTMLElement;
      if (!target) return;

      const isInteractive = target.closest('a, button, select, input, textarea, [role="button"]');
      const isTextNode = target.closest('h1, h2, h3, p, span, blockquote');
      const isCardView = target.closest('.project-hover-detector');

      setCursorHover(!!isInteractive);

      if (isCardView) {
        setCursorType('view');
      } else if (isTextNode && !isInteractive) {
        setCursorType('text');
      } else {
        setCursorType('default');
      }
    };

    window.addEventListener('mousemove', handleMouseMove);

    // Render loop for custom cursor lerp inertia
    let animId: number;
    const updateCursor = () => {
      setCursorPos((prev) => {
        const dx = cursorTargetPos.current.x - prev.x;
        const dy = cursorTargetPos.current.y - prev.y;
        if (Math.abs(dx) < 0.05 && Math.abs(dy) < 0.05) {
          return prev;
        }
        return {
          x: prev.x + dx * 0.14, // Lerp factor
          y: prev.y + dy * 0.14
        };
      });
      animId = requestAnimationFrame(updateCursor);
    };
    updateCursor();

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animId);
    };
  }, [isTouchDevice]);

  // Scroll watcher: navigation pill size morphing + section visibility tracker
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);

      // Simple active anchor tracker
      const sections = ['hero', 'services', 'projects', 'about', 'contact'];
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 200 && rect.bottom >= 200) {
            setActiveSection(section);
          }
        }
      }

      // Check stats counters intersection
      if (statsSectionRef.current && !hasAnimatedStats) {
        const rect = statsSectionRef.current.getBoundingClientRect();
        if (rect.top <= window.innerHeight - 80) {
          setHasAnimatedStats(true);
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [hasAnimatedStats]);

  // Statistics counter animations
  useEffect(() => {
    if (!hasAnimatedStats) return;

    const targets = { projects: 4, disciplines: 5, tools: 22, lighthouse: 97 };
    let frame = 0;
    const duration = 60; // 60 frames

    const timer = setInterval(() => {
      frame++;
      const progress = frame / duration;
      
      setStats({
        projects: Math.min(targets.projects, Math.floor(progress * targets.projects)),
        disciplines: Math.min(targets.disciplines, Math.floor(progress * targets.disciplines)),
        tools: Math.min(targets.tools, Math.floor(progress * targets.tools)),
        lighthouse: Math.min(targets.lighthouse, Math.floor(progress * targets.lighthouse))
      });

      if (frame >= duration) {
        clearInterval(timer);
        setStats(targets);
      }
    }, 16);

    return () => clearInterval(timer);
  }, [hasAnimatedStats]);

  // Navigation click dispatcher
  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const target = document.getElementById(id);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Horizontal scroll calculations inside Project Rails
  const handleScrollProgress = (e: React.UIEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    const maxScroll = el.scrollWidth - el.clientWidth;
    if (maxScroll <= 0) return;
    setScrollProgress(el.scrollLeft / maxScroll);
  };

  // 3D card tilt calculator on hover mouse interaction
  const handleCardMouseMove = (id: string, e: React.MouseEvent<HTMLDivElement>) => {
    if (isTouchDevice) return;
    const card = e.currentTarget;
    const rect = card.getBoundingClientRect();
    
    // Position of hover inside bounds
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;
    
    // Convert to percentage coordinates from -1.0 to 1.0
    const x = (clientX / rect.width) * 2 - 1;
    const y = (clientY / rect.height) * 2 - 1;

    // Apply rotation calculation
    const rotateIntensity = 10;
    setCardTilts((prev) => ({
      ...prev,
      [id]: {
        rx: -y * rotateIntensity,
        ry: x * rotateIntensity,
        mx: clientX,
        my: clientY
      }
    }));
  };

  const handleCardMouseLeave = (id: string) => {
    setCardTilts((prev) => ({
      ...prev,
      [id]: { rx: 0, ry: 0, mx: -100, my: -100 }
    }));
  };

  // Simulated Submission trigger
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || isSubmitting) return;

    setIsSubmitting(true);
    
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitSuccess(true);
      // Clean structure
      setFormData({
        name: '',
        email: '',
        company: '',
        budget: '$5k - $10k',
        message: ''
      });
      // Delay resetting success state
      setTimeout(() => setSubmitSuccess(false), 5000);
    }, 1400);
  };

  return (
    <div className="relative min-h-screen bg-carbon-black text-bone-white selection:bg-ember-primary selection:text-carbon-black overflow-hidden font-sans">
      
      {/* 1. Structural Noise grain layer */}
      <div className="noise-overlay" />
      
      {/* 2. Embedded background custom grid outline */}
      <div className="absolute inset-0 grid-overlay opacity-30 pointer-events-none z-0" />

      {/* 3. Custom Vector Cursor - disabled on Touch and Desktop loaders */}
      {!isTouchDevice && !loading && (
        <>
          {/* Central Dot */}
          <div 
            className="fixed pointer-events-none z-[9999] -translate-x-1/2 -translate-y-1/2 rounded-full transition-transform duration-300"
            style={{
              left: `${cursorPos.x}px`,
              top: `${cursorPos.y}px`,
              width: cursorHover ? '6px' : '4px',
              height: cursorHover ? '6px' : '4px',
              backgroundColor: cursorType === 'view' ? '#FBD5A5' : '#F37512',
            }}
          />
          {/* Outer Ring */}
          <div 
            className="fixed pointer-events-none z-[9998] -translate-x-1/2 -translate-y-1/2 rounded-full border flex items-center justify-center transition-all duration-300"
            style={{
              left: `${cursorPos.x}px`,
              top: `${cursorPos.y}px`,
              width: cursorType === 'view' ? '65px' : cursorHover ? '32px' : '22px',
              height: cursorType === 'view' ? '65px' : cursorHover ? '32px' : '22px',
              borderColor: cursorType === 'view' ? '#F37512' : cursorHover ? 'rgba(243,117,18,0.5)' : 'rgba(242,242,236,0.15)',
              backgroundColor: cursorType === 'view' ? 'rgba(243,117,18,0.08)' : 'transparent',
              backdropFilter: cursorType === 'view' ? 'blur(1px)' : 'none',
            }}
          >
            {cursorType === 'view' && (
              <span className="font-mono text-[9px] font-bold tracking-widest text-ember-primary">VIEW</span>
            )}
            {cursorType === 'text' && (
              <div className="w-[1px] h-3 bg-ember-primary/60" />
            )}
          </div>
        </>
      )}

      {/* 4. Cinematic Industrial First Paint Page Loader */}
      {loading && (
        <div 
          className="fixed inset-0 bg-carbon-black z-[1000] flex flex-col justify-between p-6 m-0 cursor-none select-none"
          id="page-loader"
        >
          {/* Top segment */}
          <div className="flex items-center justify-between text-[11px] font-mono text-bone-white/30 tracking-wider">
            <span>SYS_LOC: NEW_DELHI_IN</span>
            <span className="text-ember-primary animate-pulse">● EXECUTING_PORTFOLIO_BOOT</span>
            <span>SHIPPED // 2024–2025</span>
          </div>

          {/* Central Graphic Block */}
          <div className="flex flex-col items-center justify-center space-y-6">
            {/* Rotating Tactical Diamond visual identifier */}
            <div className="relative w-16 h-16 border border-ember-primary/20 rotate-45 flex items-center justify-center animate-spin" style={{ animationDuration: '6s' }}>
              <div className="w-10 h-10 border-2 border-dashed border-ember-primary/40 rotate-45 flex items-center justify-center">
                <div className="w-4 h-4 bg-ember-primary animate-ping" />
              </div>
            </div>

            <div className="text-center space-y-1.5 pt-4">
              <h1 className="font-serif font-extralight text-3xl tracking-tight text-bone-white">
                Jayesh Vasava
              </h1>
              <p className="font-mono text-xs uppercase tracking-[0.25em] text-ember-primary">
                WORKSPACE SYSTEM
              </p>
            </div>

            {/* Readout log console */}
            <div className="w-full max-w-[340px] h-[90px] rounded border border-bone-white/10 bg-graphite-dark/60 p-3 font-mono text-[9px] text-bone-white/40 leading-relaxed text-left space-y-1 overflow-hidden select-none">
              {loadingLogs.slice(-4).map((log, i) => (
                <div key={i} className="truncate">{log}</div>
              ))}
            </div>
          </div>

          {/* Bottom progress bar */}
          <div className="w-full max-w-xl mx-auto space-y-2">
            <div className="flex justify-between items-end font-mono text-xs text-bone-white/30">
              <span className="text-ember-primary font-bold uppercase tracking-widest">Compiling Core Synapses</span>
              <span className="text-bone-white/80 font-bold">{loadingProgress}%</span>
            </div>
            <div className="h-0.5 bg-bone-white/5 relative">
              <div 
                className="absolute top-0 left-0 h-full bg-ember-primary shadow-[0_0_10px_#F37512] transition-all duration-100"
                style={{ width: `${loadingProgress}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* 5. Header Navigation Pill Container (morphs into compact floating nav on scroll) */}
      <nav 
        className={`fixed top-0 left-0 w-full z-120 transition-all duration-500 ease-in-out px-4 py-4 md:px-8 ${
          scrolled ? 'pt-3' : 'pt-6'
        }`}
        id="navbar-system"
      >
        <div 
          className={`mx-auto flex items-center justify-between transition-all duration-500 ${
            scrolled 
              ? 'max-w-[720px] bg-graphite-dark/75 border border-bone-white/10 p-2.5 rounded-full backdrop-blur-md shadow-2xl' 
              : 'max-w-7xl bg-transparent border-b border-bone-white/5 pb-4'
          }`}
        >
          {/* Left Wing logo */}
          <div 
            onClick={() => scrollToSection('hero')}
            className={`flex items-center gap-2.5 cursor-pointer group transition-all duration-300 ${
              scrolled ? 'pl-3' : 'pl-0'
            }`}
          >
            {/* Spin diamond on hover */}
            <div className="w-6 h-6 border border-ember-primary/40 rotate-45 flex items-center justify-center bg-carbon-black group-hover:rotate-[135deg] transition-all duration-700">
              <div className="w-2.5 h-2.5 bg-ember-primary" />
            </div>
            
            <div className="flex flex-col text-left font-mono">
              <span className="text-[11px] font-bold tracking-widest leading-none text-bone-white text-nowrap">
                JAYESH VASAVA
              </span>
              <span className="text-[8px] tracking-widest leading-none text-bone-white/40 font-light max-md:hidden">
                PORTFOLIO
              </span>
            </div>
          </div>

          {/* Center navigation links */}
          <div className="hidden md:flex items-center gap-1 font-mono text-[11px]">
            {[
              { id: 'projects', tag: '01', label: 'Work' },
              { id: 'services', tag: '02', label: 'Services' },
              { id: 'about', tag: '03', label: 'About' },
              { id: 'contact', tag: '04', label: 'Contact' }
            ].map((link) => (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className={`relative px-4 py-1.5 rounded-full transition-all duration-300 hover:text-ember-primary text-nowrap flex items-center gap-1 ${
                  activeSection === link.id 
                    ? 'text-ember-primary bg-bone-white/5 font-semibold' 
                    : 'text-bone-white/60 font-light'
                }`}
              >
                <span className="text-[8px] opacity-40 text-ember-primary">{link.tag}</span>
                {link.label}
                {activeSection === link.id && (
                  <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1.5 h-[3px] bg-ember-primary rounded-full" />
                )}
              </button>
            ))}
          </div>

          {/* Right Action Trigger Pill */}
          <div className="flex items-center gap-2">
            {/* Cognitive Brain trigger button */}
            <button
              onClick={() => setIsTerminalOpen(true)}
              className="p-2 mr-1 rounded-full border border-ember-primary/20 bg-ember-primary/5 hover:bg-ember-primary/10 text-ember-primary hover:border-ember-primary/50 transition-all duration-300 animate-pulse flex items-center gap-1 text-[10px] uppercase font-mono tracking-widest hidden lg:flex"
              title="Activate High Thinking jayesh vasava chart API"
            >
              <Terminal className="w-3.5 h-3.5 text-ember-primary" />
              Brain Inside
            </button>

            <button
              onClick={() => scrollToSection('contact')}
              className={`hidden sm:flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-widest bg-bone-white text-carbon-black py-2.5 px-5 rounded-full font-bold hover:bg-ember-primary hover:-translate-y-0.5 active:translate-y-0 transition-all duration-300 ${
                scrolled ? 'text-[9px] py-2 px-4' : ''
              }`}
            >
              Start a project
              <ArrowRight className="w-3 h-3" />
            </button>

            {/* Mobile menu trigger */}
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-full border border-bone-white/10 bg-graphite-dark hover:bg-bone-white/5 transition-all text-bone-white"
            >
              {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </nav>

      {/* 6. Mobile slide down full screen navigation menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-110 bg-carbon-black bg-opacity-95 backdrop-blur-lg flex flex-col justify-between p-8 font-mono select-none">
          <div className="flex justify-between items-center border-b border-bone-white/5 pb-4 mt-16">
            <span className="text-xs text-bone-white/30 tracking-widest uppercase">Index Selector</span>
            <button 
              onClick={() => setIsTerminalOpen(true)}
              className="flex items-center gap-1.5 text-[10px] text-ember-primary border border-ember-primary/20 bg-ember-primary/5 py-1 px-2.5 rounded-full"
            >
              <Terminal className="w-3.5 h-3.5" />
              jayesh vasava chart
            </button>
          </div>

          <div className="flex flex-col space-y-6 pt-10 text-left">
            {[
              { id: 'projects', tag: '01', desc: 'Case Studies', label: 'WORK' },
              { id: 'services', tag: '02', desc: 'Craft Pillars', label: 'SERVICES' },
              { id: 'about', tag: '03', desc: 'Curriculum Vitae', label: 'ABOUT' },
              { id: 'contact', tag: '04', desc: 'Say Hello', label: 'CONTACT' }
            ].map((link) => (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className="group flex flex-col text-left items-start border-b border-bone-white/5 pb-3 w-full"
              >
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-ember-primary font-bold">{link.tag}</span>
                  <span className="text-[9px] text-bone-white/30 tracking-wider uppercase font-light translate-y-0.5">{link.desc}</span>
                </div>
                <span className="font-serif text-3xl font-light text-bone-white tracking-snug hover:text-ember-primary transition-colors hover:pl-2 duration-300 pt-1">
                  {link.label}
                </span>
              </button>
            ))}
          </div>

          <div className="border-t border-bone-white/5 pt-6 flex flex-col gap-4 text-left">
            <div className="text-[10px] text-bone-white/30 truncate">EMAIL // jv172484@gmail.com</div>
            <div className="flex gap-4">
              <a href="https://github.com/jayeshvasava" target="_blank" rel="noreferrer" className="text-bone-white/50 hover:text-ember-primary text-xs flex items-center gap-1">
                <Github className="w-3.5 h-3.5" /> GH
              </a>
              <a href="https://linkedin.com/in/jayesh-vasava" target="_blank" rel="noreferrer" className="text-bone-white/50 hover:text-ember-primary text-xs flex items-center gap-1">
                <Linkedin className="w-3.5 h-3.5" /> IN
              </a>
              <a href="https://instagram.com/jayeshvasava" target="_blank" rel="noreferrer" className="text-bone-white/50 hover:text-ember-primary text-xs flex items-center gap-1">
                <Instagram className="w-3.5 h-3.5" /> IG
              </a>
            </div>
          </div>
        </div>
      )}

      {/* 7. COGNITIVE TERMINAL MODULE (Sliding AI core) */}
      <CognitiveTerminal 
        isOpen={isTerminalOpen} 
        onClose={() => setIsTerminalOpen(false)} 
      />

      {/* 8. MAIN VIEWPORT */}
      <main className="relative z-10">

        {/* =========================================================================
            SECTION 1: HERO VIEWPORT (Full Screen)
            ========================================================================= */}
        <section 
          id="hero"
          className="relative min-h-screen flex flex-col justify-between pt-24 pb-8 px-6 md:px-12 max-w-7xl mx-auto border-b border-bone-white/5 overflow-hidden"
        >
          {/* Top metadata tracking lane */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-bone-white/5 pb-4 text-left gap-2 pt-4">
            <div className="flex items-center gap-2 font-mono text-[9px] tracking-widest text-[#a0dbbf] bg-[#a0dbbf]/5 py-1 px-3 border border-[#a0dbbf]/15 rounded-full font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-[#a0dbbf] animate-ping" />
              PULSING_AVAILABILITY // OPEN_TO_COLLABORATIONS
            </div>
            
            <div className="font-mono text-[9px] md:text-[10px] tracking-wider text-bone-white/40">
              Jayesh Vasava · Portfolio | 2024–2025 Index | Designed · Built · Shipped
            </div>
          </div>

          {/* Hero Split Layout Area */}
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center py-6 md:py-10">
            {/* LEFT HALF CONTENT */}
            <div className="lg:col-span-7 flex flex-col space-y-6 text-left">
              <div className="space-y-2">
                <span className="font-mono text-xs text-ember-primary tracking-widest uppercase block font-semibold">
                  — Web Developer & UI/UX Designer
                </span>
                
                {/* Splitting title reveal */}
                <h1 className="font-serif text-5xl md:text-6xl xl:text-7xl font-extralight tracking-tight leading-[1.05] text-bone-white">
                  Crafting <br className="hidden md:block"/>
                  <span className="word-mask">
                    <span className="italic font-serif font-light text-ember-primary shadow-sm">Digital</span>
                  </span> Experiences.
                </h1>
              </div>

              <p className="font-sans text-sm md:text-base text-bone-white/60 font-light leading-relaxed max-w-xl">
                Computer Science graduate from <span className="text-bone-white font-medium border-b border-bone-white/20 pb-0.5">NSUT</span>, currently shipping live interactive digital learning environments at <span className="text-bone-white font-medium border-b border-bone-white/20 pb-0.5">PhysicsWallah</span>. Specialized in crafting bespoke UI/UX, responsive front-end setups, and full-stack GenAI integrations — refining rough wireframes into live immersive engineering.
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button 
                  onClick={() => scrollToSection('projects')}
                  className="bg-ember-primary border border-ember-primary text-carbon-black hover:bg-transparent hover:text-ember-primary font-mono text-[11px] uppercase tracking-widest font-bold py-3.5 px-8 rounded-full transition-all duration-300 shadow-xl hover:-translate-y-0.5 active:translate-y-0 relative overflow-hidden"
                >
                  View Projects
                </button>
                
                <button
                  onClick={() => scrollToSection('contact')}
                  className="border border-bone-white/10 hover:border-ember-primary hover:text-ember-primary font-mono text-[11px] uppercase tracking-widest text-bone-white/75 py-3.5 px-8 rounded-full transition-all duration-300 hover:bg-bone-white/5 shadow-md flex items-center gap-1.5"
                >
                  Contact Me
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* RIGHT HALF ARTWORK */}
            <div className="lg:col-span-5 h-[340px] md:h-[420px] lg:h-full relative flex items-center justify-center">
              <WorkspaceVisuals />
            </div>
          </div>

          {/* Bottom margin statistic bar */}
          <div className="border-t border-bone-white/5 pt-4 flex flex-col md:flex-row justify-between items-start md:items-center text-left gap-4 font-mono select-none">
            {/* Mini prompt widget indicator */}
            <div className="flex items-center gap-2 text-[10px] text-bone-white/40">
              <Sparkles className="w-3.5 h-3.5 text-ember-primary" />
              <span>Stuck on questions? Ask the Cognitive System right here:</span>
              <button
                onClick={() => setIsTerminalOpen(true)}
                className="text-ember-primary font-bold hover:underline ml-1 cursor-pointer flex items-center gap-0.5"
              >
                [WAKE UP ASSISTANT]
              </button>
            </div>

            <div className="flex gap-6 text-[10px] uppercase tracking-widest text-bone-white/30 max-md:grid max-md:grid-cols-3 max-md:w-full">
              <div className="flex flex-col">
                <span className="text-bone-white font-bold text-xs">04</span>
                <span>Live Projects</span>
              </div>
              <div className="flex flex-col border-l border-bone-white/10 pl-4 max-md:pl-2">
                <span className="text-bone-white font-bold text-xs">05</span>
                <span>Disciplines</span>
              </div>
              <div className="flex flex-col border-l border-bone-white/10 pl-4 max-md:pl-2">
                <span className="text-bone-white font-bold text-xs">22</span>
                <span>Tools & Techs</span>
              </div>
            </div>
          </div>
        </section>


        {/* =========================================================================
            SECTION 2: CORE DISCIPLINES & SERVICES (Grid)
            ========================================================================= */}
        <section 
          id="services"
          className="py-20 px-6 md:px-12 max-w-7xl mx-auto border-b border-bone-white/5"
        >
          {/* Header Row */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 text-left gap-3">
            <div className="space-y-1">
              <span className="font-mono text-xs text-ember-primary tracking-widest uppercase font-semibold">
                — Craft Capabilities // 002
              </span>
              <h2 className="font-serif text-3xl md:text-5xl font-extralight tracking-tight text-bone-white text-nowrap">
                Engineered <span className="italic font-light text-ember-primary">Disciplines</span>.
              </h2>
            </div>
            
            <p className="font-mono text-[10px] text-bone-white/30 uppercase tracking-widest max-w-[280px]">
              Tuning interactive mechanics with responsive, bulletproof layouts.
            </p>
          </div>

          {/* Cards 3-column Layout */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {CORE_SERVICES.map((service, idx) => {
              const tilt = cardTilts[service.id] || { rx: 0, ry: 0, mx: -100, my: -100 };
              return (
                <div
                  key={service.id}
                  onMouseMove={(e) => handleFormSubmit ? handleCardMouseMove(service.id, e) : null}
                  onMouseLeave={() => handleCardMouseLeave(service.id)}
                  className="relative h-[250px] md:h-[260px] rounded-xl border border-bone-white/10 bg-graphite-dark/45 p-6 flex flex-col justify-between overflow-hidden transition-all duration-300 hover:border-ember-primary/25 cursor-default select-none shine-sweep shadow-xl"
                  style={{
                    transform: `perspective(1000px) rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg)`,
                    transition: tilt.rx === 0 ? 'all 0.5s ease-out' : 'transform 0.05s ease-out, border-color 0.3s'
                  }}
                  id={`service-card-${service.id}`}
                >
                  {/* SPOTLIGHT GRADIENT BACKING */}
                  <div 
                    className="absolute inset-0 pointer-events-none transition-opacity duration-300 opacity-0 hover:opacity-100"
                    style={{
                      background: `radial-gradient(130px circle at ${tilt.mx}px ${tilt.my}px, rgba(243, 117, 18, 0.075) 0%, transparent 80%)`,
                      opacity: tilt.mx === -100 ? 0 : 1
                    }}
                  />

                  {/* Top corner details */}
                  <div className="flex items-start justify-between">
                    <span className="font-mono text-xs text-ember-primary font-bold">
                      /{service.index}
                    </span>
                    <span className="font-mono text-[9px] text-bone-white/20 tracking-wider">
                      CAP_SYS_{service.index}
                    </span>
                  </div>

                  {/* Body Content */}
                  <div className="space-y-2 mt-4 text-left">
                    <h3 className="font-serif text-lg font-normal tracking-tight text-bone-white flex items-center gap-1.5">
                      {service.title}
                    </h3>
                    <p className="font-sans text-xs text-bone-white/50 leading-relaxed font-light">
                      {service.description}
                    </p>
                  </div>

                  {/* Capabilities pill tags - expanding/highlighting slightly on hover */}
                  <div className="flex flex-wrap gap-1.5 pt-4">
                    {service.capabilities.slice(0, 3).map((cap, capIdx) => (
                      <span 
                        key={capIdx}
                        className="font-mono text-[8px] bg-bone-white/5 border border-bone-white/5 py-0.5 px-2 rounded-full text-bone-white/30 group-hover:text-ember-primary tracking-wider transition-colors"
                      >
                        {cap}
                      </span>
                    ))}
                    {service.capabilities.length > 3 && (
                      <span className="font-mono text-[8px] border border-dashed border-bone-white/10 text-bone-white/20 py-0.5 px-2 rounded-full">
                        +{service.capabilities.length - 3}
                      </span>
                    )}
                  </div>

                  {/* Industrial corner brackets */}
                  <div className="absolute top-1 right-1 w-1 h-3 border-t border-r border-bone-white/10 group-hover:border-ember-primary/40 transition-colors" />
                  <div className="absolute bottom-1 left-1 w-1 h-3 border-b border-l border-bone-white/10 group-hover:border-ember-primary/40 transition-colors" />
                </div>
              );
            })}

            {/* 6th Interactive CTA card */}
            <div 
              onClick={() => scrollToSection('contact')}
              className="relative h-[250px] md:h-[260px] rounded-xl border border-dashed border-ember-primary/20 bg-ember-primary/5 hover:bg-ember-primary/10 p-6 flex flex-col justify-between overflow-hidden transition-all duration-300 hover:border-ember-primary/50 cursor-pointer text-left select-none shadow-2xl"
              id="service-card-cta"
            >
              <div className="flex justify-between items-start">
                <span className="font-mono text-xs text-ember-primary font-bold">/06</span>
                <span className="w-1.5 h-1.5 rounded-full bg-ember-primary animate-ping" />
              </div>

              <div className="space-y-2 py-4">
                <h3 className="font-serif text-2xl font-extralight text-bone-white leading-tight">
                  Have something else in mind?
                </h3>
                <p className="font-mono text-[10px] text-ember-light/60 tracking-wider">
                  Let's wire custom integrations, robust prompt systems, and scalable full-stack pipelines. Talk directly with my team.
                </p>
              </div>

              <span className="font-mono text-[10px] font-bold tracking-widest text-ember-primary flex items-center gap-1.5 uppercase hover:pl-1.5 transition-all">
                Initiate proposal
                <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>
        </section>


        {/* =========================================================================
            SECTION 3: HORIZONTAL GALLERY / PROJECTS
            ========================================================================= */}
        <section 
          id="projects"
          className="py-20 px-6 md:px-12 max-w-7xl mx-auto border-b border-bone-white/5 scroll-mt-20 overflow-hidden"
        >
          {/* Header row - in normal flow, flex layout to avoid overlaps */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 text-left gap-4">
            <div className="space-y-1">
              <span className="font-mono text-xs text-ember-primary tracking-widest uppercase font-semibold">
                — Handcrafted Deliverables // 003
              </span>
              <h2 className="font-serif text-3xl md:text-5xl font-extralight tracking-tight text-bone-white text-nowrap">
                Shipped <span className="italic font-light text-ember-primary">Products</span>.
              </h2>
            </div>
            
            <div className="flex items-center gap-4 text-left">
              <p className="font-mono text-[10px] text-bone-white/30 uppercase tracking-widest max-w-[240px] max-md:hidden">
                Drag or scroll horizontally inside desktop layouts to discover core projects.
              </p>
              {/* Progress visual lane */}
              <div className="w-32 h-[1px] bg-bone-white/10 relative overflow-hidden hidden sm:block">
                <div 
                  className="absolute top-0 left-0 h-full bg-ember-primary transition-all duration-300"
                  style={{ width: `${scrollProgress * 100}%` }}
                />
              </div>
            </div>
          </div>

          {/* Desktop scroll rail & mobile vertical gallery container */}
          <div 
            ref={scrollContainerRef}
            onScroll={handleScrollProgress}
            className="flex flex-col md:flex-row gap-6 overflow-x-auto overflow-y-hidden py-4 -mx-4 px-4 scrollbar-thin scroll-smooth snap-x snap-mandatory relative"
            style={{
              scrollbarWidth: 'none',
              msOverflowStyle: 'none',
            }}
            id="projects-gallery"
          >
            {PORTFOLIO_PROJECTS.map((proj) => (
              <a 
                key={proj.id}
                href={proj.url}
                target="_blank"
                rel="noopener noreferrer"
                className="project-hover-detector block relative flex-shrink-0 w-full md:w-[480px] h-[480px] md:h-[520px] rounded-xl overflow-hidden cursor-none group snap-center border border-bone-white/5 shadow-2xl transition-all duration-300"
                id={`project-card-${proj.id}`}
              >
                {/* 1. Procedural vector pattern - replaces static stock images */}
                <ProceduralPattern type={proj.patternType} color={proj.accent} />

                {/* 2. Visual Content Layer */}
                <div className="absolute inset-0 p-6 flex flex-col justify-between z-10">
                  {/* Top Header info */}
                  <div className="flex items-start justify-between">
                    <span className="font-mono text-xs font-semibold text-bone-white bg-carbon-black bg-opacity-70 border border-bone-white/10 px-3 py-1 rounded-full">
                      {proj.index}
                    </span>
                    <span className="font-mono text-[9px] text-[#a0dbbf] bg-[#a0dbbf]/5 border border-[#a0dbbf]/15 px-2.5 py-0.5 rounded-full uppercase font-bold tracking-widest">
                      {proj.year} Index
                    </span>
                  </div>

                  {/* Detail panels */}
                  <div className="space-y-4 text-left">
                    <div className="space-y-1 bg-carbon-black bg-opacity-75 backdrop-blur-xs p-4 rounded-lg border border-bone-white/5">
                      <span className="font-mono text-[9px] uppercase tracking-widest text-ember-primary font-semibold">
                        {proj.category}
                      </span>
                      <h3 className="font-serif text-2xl font-light text-bone-white flex items-center gap-1">
                        {proj.title}
                      </h3>
                      <p className="font-sans text-xs text-bone-white/50 leading-relaxed font-light">
                        {proj.description}
                      </p>
                    </div>

                    {/* Tags column */}
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {proj.tags.map((tag, tIdx) => (
                        <span 
                          key={tIdx}
                          className="font-mono text-[8px] uppercase tracking-wider bg-carbon-black border border-bone-white/10 text-bone-white/40 py-1 px-2.5 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* Bottom link indicator */}
                    <div className="flex items-center gap-1 font-mono text-[10px] font-bold text-ember-primary uppercase tracking-widest pt-2 group-hover:underline">
                      Launch live project
                      <ExternalLink className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </div>

                {/* Tactical details */}
                <div className="absolute top-1 left-1 w-2 h-2 border-t border-l border-ember-primary/40 opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="absolute bottom-1 right-1 w-2 h-2 border-b border-r border-ember-primary/40 opacity-0 group-hover:opacity-100 transition-opacity" />
              </a>
            ))}

            {/* End of rail CTA card */}
            <div 
              onClick={() => scrollToSection('contact')}
              className="flex-shrink-0 w-full md:w-[320px] h-[480px] md:h-[520px] rounded-xl border border-dashed border-bone-white/10 bg-graphite-dark/20 p-6 flex flex-col justify-between text-left snap-center shadow-lg"
              id="projects-card-more"
            >
              <div className="flex justify-between items-start font-mono text-xs text-bone-white/30">
                <span>INDEX_005</span>
                <span>STATUS: QUEUED</span>
              </div>

              <div className="space-y-2">
                <h3 className="font-serif text-2xl font-extralight text-bone-white leading-tight">
                  More on the <br className="hidden md:block"/>way.
                </h3>
                <p className="font-mono text-[10px] text-bone-white/40 leading-relaxed">
                  Currently compiling three new full-stack Saas models and customized interactive dashboards for local and global design collectives.
                </p>
              </div>

              <button 
                onClick={() => scrollToSection('contact')}
                className="text-ember-primary font-mono text-[10px] uppercase font-bold tracking-widest flex items-center gap-1 shadow-sm pb-1 border-b border-ember-primary/20 hover:border-ember-primary text-left"
              >
                Hire Jayesh for project
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </section>


        {/* =========================================================================
            SECTION 4: ABOUT ME / RESUME (Split layout)
            ========================================================================= */}
        <section 
          id="about"
          className="py-20 px-6 md:px-12 max-w-7xl mx-auto border-b border-bone-white/5 scroll-mt-20"
        >
          {/* Headline section banner */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 text-left gap-4">
            <div className="space-y-1">
              <span className="font-mono text-xs text-ember-primary tracking-widest uppercase font-semibold">
                — Background Profile // 004
              </span>
              <h2 className="font-serif text-3xl md:text-5xl font-extralight tracking-tight text-bone-white">
                Designed end-to-end.<br/>
                <span className="italic font-serif font-light text-ember-primary">Built with intention</span>.
              </h2>
            </div>
            
            <p className="font-mono text-[10px] text-bone-white/30 uppercase tracking-widest max-w-[260px]">
              Combining tactical visual depth with strict clean-code layouts.
            </p>
          </div>

          {/* About Split Layout Rows */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            
            {/* LEFT HALF PORTRAIT MONOGRAM */}
            <div className="lg:col-span-5 flex justify-center">
              <div 
                className="relative w-full max-w-[360px] aspect-[4/5] rounded-xl border border-bone-white/10 bg-graphite-dark p-6 flex flex-col justify-between overflow-hidden shadow-2xl select-none text-left shine-sweep"
                id="monogram-portrait-card"
              >
                {/* Visual grid backing */}
                <div className="absolute inset-0 grid-overlay opacity-15" />
                
                {/* Meta strip */}
                <div className="flex items-center justify-between font-mono text-[9px] text-bone-white/30 pb-2 border-b border-bone-white/5">
                  <span>Profile · 001</span>
                  <span className="flex items-center gap-1 font-bold text-[#a0dbbf]">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#a0dbbf] animate-pulse" /> LIVE
                  </span>
                </div>

                {/* Overlapping Monogram Headline */}
                <div className="flex-1 flex items-center justify-center relative">
                  <div className="font-serif text-[140px] md:text-[180px] font-extrabold flex leading-none translate-y-3">
                    <span className="text-bone-white -translate-x-3">H</span>
                    <span className="text-ember-primary italic font-light -translate-x-12">G</span>
                  </div>
                  {/* Glowing amber halo inside */}
                  <div className="absolute w-24 h-24 rounded-full bg-ember-primary/10 blur-[40px] pointer-events-none" />
                </div>

                {/* Bottom Caption detail */}
                <div className="space-y-2 border-t border-bone-white/5 pt-4">
                  <p className="font-mono text-[9px] text-bone-white/30 uppercase tracking-widest leading-none">
                    Jayesh Vasava // Workspace
                  </p>
                  <p className="font-serif text-sm font-light text-bone-white/85 leading-normal">
                    Based in India / Open to collaborations · NSUT · 2024
                  </p>
                </div>

                {/* Corner details */}
                <div className="absolute top-1 left-1 w-2 h-2 border-t border-l border-ember-primary/40" />
                <div className="absolute top-1 right-1 w-2 h-2 border-t border-r border-ember-primary/40" />
                <div className="absolute bottom-1 left-1 w-2 h-2 border-b border-l border-ember-primary/40" />
                <div className="absolute bottom-1 right-1 w-2 h-2 border-b border-r border-ember-primary/40" />
              </div>
            </div>

            {/* RIGHT HALF BIOMETRIC PROFILE SHEET */}
            <div className="lg:col-span-7 space-y-8 text-left">
              
              {/* Profile copy blocks */}
              <div className="space-y-4 font-sans text-sm font-light leading-relaxed text-bone-white/70">
                <p>
                  I'm a <span className="text-bone-white font-medium">Computer Science graduate from NSUT</span> (Netaji Subhas University of Technology). I am currently dedicated as a Content R&D Trainee at <span className="text-bone-white font-medium border-b border-bone-white/20 pb-0.5">PhysicsWallah</span>, where I assist in constructing and scaling real-time, consumer-facing digital learning suites with highly responsive components.
                </p>
                <p>
                  My engineering practice lives at the intersection of <span className="text-ember-primary font-normal">precise technical math</span> and luxurious typography layout. Since transitioning from plain coding models, I focus heavily on writing reliable multi-agent system logic (LLMs), custom data integrations, and modular React architectures that hit 100% Google Lighthouse benchmarks.
                </p>
              </div>

              {/* Skill Bars with shimmer effect */}
              <div className="space-y-3 pt-2">
                <span className="font-mono text-[10px] text-ember-primary tracking-widest uppercase font-bold block mb-1">
                  — EXPERTISE_INDEX
                </span>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {EXPERTISE_SKILLS.slice(0, 6).map((skill, index) => (
                    <div key={index} className="space-y-1 bg-graphite-dark/60 p-3 rounded-lg border border-bone-white/5">
                      <div className="flex justify-between items-center text-[10px] font-mono font-bold tracking-tight text-bone-white/80">
                        <span>{skill.name}</span>
                        <span className="text-ember-primary">{skill.percentage}%</span>
                      </div>
                      <div className="h-1 bg-bone-white/5 rounded-full overflow-hidden relative">
                        <div 
                          className="h-full bg-ember-primary rounded-full transition-all duration-1000"
                          style={{ 
                            width: hasAnimatedStats ? `${skill.percentage}%` : '0%',
                            backgroundImage: 'linear-gradient(90deg, rgba(255,255,255,0.15) 25%, transparent 25%)'
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Categorised tech stack pills (4 columns/rows) */}
              <div className="space-y-4 pt-4">
                <span className="font-mono text-[10px] text-bone-white/40 tracking-widest uppercase font-bold block border-b border-bone-white/5 pb-2">
                  Categorised Stack Pills
                </span>
                
                <div className="space-y-3">
                  {TECH_STOCKS_CATEGORIES.map((category, idx) => (
                    <div key={idx} className="flex flex-col sm:flex-row sm:items-center text-left gap-2 sm:gap-4">
                      <span className="font-mono text-[10px] text-ember-primary font-bold min-w-[140px] uppercase">
                        {category.category} //
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {category.items.map((item, itemIdx) => (
                          <span 
                            key={itemIdx}
                            className="font-mono text-[9px] bg-bone-white/5 border border-bone-white/5 py-1 px-2.5 rounded-full text-bone-white/70 hover:border-ember-primary/20 hover:text-ember-primary transition-all cursor-default"
                          >
                            {item}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Counter stats inside viewport */}
              <div 
                ref={statsSectionRef}
                className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6 border-t border-bone-white/5"
              >
                <div className="text-left py-2 font-mono">
                  <div className="text-3xl font-extralight text-ember-primary tracking-tight font-serif leading-none">
                    0{stats.projects}
                  </div>
                  <div className="text-[9px] uppercase tracking-wider text-bone-white/30 pt-1">
                    Live Projects
                  </div>
                </div>
                
                <div className="text-left py-2 font-mono border-l border-bone-white/5 pl-4">
                  <div className="text-3xl font-extralight text-ember-primary tracking-tight font-serif leading-none">
                    0{stats.disciplines}
                  </div>
                  <div className="text-[9px] uppercase tracking-wider text-bone-white/30 pt-1">
                    Disciplines
                  </div>
                </div>

                <div className="text-left py-2 font-mono border-l border-bone-white/5 pl-4">
                  <div className="text-3xl font-extralight text-[#a0dbbf] tracking-tight font-serif leading-none">
                    {stats.tools}+
                  </div>
                  <div className="text-[9px] uppercase tracking-wider text-bone-white/30 pt-1">
                    Tools Mastered
                  </div>
                </div>

                <div className="text-left py-2 font-mono border-l border-bone-white/5 pl-4">
                  <div className="text-3xl font-extralight text-[#a0dbbf] tracking-tight font-serif leading-none">
                    {stats.lighthouse}
                  </div>
                  <div className="text-[9px] uppercase tracking-wider text-bone-white/30 pt-1">
                    Lighthouse Avg
                  </div>
                </div>
              </div>

            </div>

          </div>
        </section>


        {/* =========================================================================
            SECTION 5: CONTACT (Form & direct panels)
            ========================================================================= */}
        <section 
          id="contact"
          className="py-20 px-6 md:px-12 max-w-7xl mx-auto border-b border-bone-white/5 scroll-mt-20"
        >
          {/* Mega Headline banner */}
          <div className="text-left space-y-2 mb-12">
            <span className="font-mono text-xs text-ember-primary tracking-widest uppercase font-semibold block">
              — INITIATING_LINK // 005
            </span>
            <h2 className="font-serif text-4xl sm:text-6xl md:text-7xl font-extralight tracking-tight text-bone-white leading-[1.05]">
              Let's build <br className="hidden sm:block"/>
              <span className="italic font-serif font-light text-ember-primary">something rare</span>.
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            
            {/* LEFT COLUMN: CONTACT SHEETS & FLOATING LABELS FORM */}
            <div className="lg:col-span-7 bg-graphite-dark/30 rounded-xl border border-bone-white/5 p-6 md:p-8 text-left relative overflow-hidden shadow-2xl">
              <div className="absolute inset-0 grid-overlay opacity-5 pointer-events-none" />
              
              <form onSubmit={handleFormSubmit} className="space-y-6 relative z-10">
                {/* Project Chip selection toggles */}
                <div className="space-y-3">
                  <span className="font-mono text-[9px] text-bone-white/40 tracking-wider uppercase block font-semibold">
                    What system are we fabricating?
                  </span>
                  
                  <div className="flex flex-wrap gap-2">
                    {['UI/UX Design', 'Front-end', 'GenAI Integration', 'Prompt Architecture', 'SaaS Platform', 'Other'].map((type) => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setFormType(type)}
                        className={`font-mono text-[10px] tracking-widest uppercase py-2 px-4 rounded-full border transition-all duration-300 ${
                          formType === type 
                            ? 'bg-ember-primary text-carbon-black border-ember-primary font-bold' 
                            : 'bg-transparent text-bone-white/50 border-bone-white/10 hover:border-ember-primary/30 hover:text-bone-white'
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Name field (floating labels logic) */}
                <div className="relative">
                  <input
                    type="text"
                    required
                    id="user_name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    onFocus={() => setFormFocused(prev => ({ ...prev, name: true }))}
                    onBlur={() => setFormFocused(prev => ({ ...prev, name: !!formData.name }))}
                    className="w-full bg-transparent border-b border-bone-white/15 py-3 pr-2 font-mono text-xs text-bone-white focus:outline-none focus:border-ember-primary transition-colors pr-8"
                  />
                  <label 
                    htmlFor="user_name"
                    className={`absolute left-0 bottom-0 py-3 font-mono text-xs text-bone-white/30 pointer-events-none transition-all duration-350 transform origin-left ${
                      formFocused.name || formData.name ? '-translate-y-6 scale-[0.8] text-ember-primary' : ''
                    }`}
                  >
                    IDENTIFIER [Name] *
                  </label>
                </div>

                {/* Email field */}
                <div className="relative">
                  <input
                    type="email"
                    required
                    id="user_email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    onFocus={() => setFormFocused(prev => ({ ...prev, email: true }))}
                    onBlur={() => setFormFocused(prev => ({ ...prev, email: !!formData.email }))}
                    className="w-full bg-transparent border-b border-bone-white/15 py-3 pr-2 font-mono text-xs text-bone-white focus:outline-none focus:border-ember-primary transition-colors pr-8"
                  />
                  <label 
                    htmlFor="user_email"
                    className={`absolute left-0 bottom-0 py-3 font-mono text-xs text-bone-white/30 pointer-events-none transition-all duration-350 transform origin-left ${
                      formFocused.email || formData.email ? '-translate-y-6 scale-[0.8] text-ember-primary' : ''
                    }`}
                  >
                    COMMUNICATION_LINK [Email] *
                  </label>
                </div>

                {/* Company & Budget selections layout */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                  
                  {/* Company Input */}
                  <div className="relative">
                    <input
                      type="text"
                      id="user_company"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      onFocus={() => setFormFocused(prev => ({ ...prev, company: true }))}
                      onBlur={() => setFormFocused(prev => ({ ...prev, company: !!formData.company }))}
                      className="w-full bg-transparent border-b border-bone-white/15 py-3 pr-2 font-mono text-xs text-bone-white focus:outline-none focus:border-ember-primary transition-colors pr-8"
                    />
                    <label 
                      htmlFor="user_company"
                      className={`absolute left-0 bottom-0 py-3 font-mono text-xs text-bone-white/30 pointer-events-none transition-all duration-350 transform origin-left ${
                        formFocused.company || formData.company ? '-translate-y-6 scale-[0.8] text-ember-primary' : ''
                      }`}
                    >
                      COLLECTIVE [Company Name]
                    </label>
                  </div>

                  {/* Budget Selector */}
                  <div className="flex flex-col space-y-1.5 text-left">
                    <span className="font-mono text-[9px] text-bone-white/30 uppercase tracking-wider">
                      ALLOCATION_ESTIMATE [Budget]
                    </span>
                    <select
                      value={formData.budget}
                      onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                      className="w-full bg-carbon-black border border-bone-white/10 p-2 text-xs font-mono text-bone-white focus:outline-none focus:border-ember-primary"
                    >
                      <option>&lt; $5k</option>
                      <option>$5k - $10k</option>
                      <option>$10k - $25k</option>
                      <option>$25k+</option>
                    </select>
                  </div>
                </div>

                {/* Text Message Field */}
                <div className="relative">
                  <textarea
                    rows={3}
                    id="user_message"
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    onFocus={() => setFormFocused(prev => ({ ...prev, message: true }))}
                    onBlur={() => setFormFocused(prev => ({ ...prev, message: !!formData.message }))}
                    className="w-full bg-transparent border-b border-bone-white/15 py-3 pr-2 font-mono text-xs text-bone-white focus:outline-none focus:border-ember-primary transition-colors pr-8 resize-none"
                  />
                  <label 
                    htmlFor="user_message"
                    className={`absolute left-0 bottom-0 py-3 font-mono text-xs text-bone-white/30 pointer-events-none transition-all duration-350 transform origin-left ${
                      formFocused.message || formData.message ? '-translate-y-14 scale-[0.8] text-ember-primary' : ''
                    }`}
                  >
                    COGNITIVE_TRANSMISSION [Message context]
                  </label>
                </div>

                {/* Submit button with sweep highlight effect */}
                <div className="pt-4 flex items-center justify-between flex-wrap gap-4">
                  <div className="font-mono text-[9px] text-bone-white/30 leading-tight">
                    * Required validation parameters <br/>
                    Will process with typical 1.4s dispatch latency.
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting || !formData.name || !formData.email}
                    className="bg-ember-primary font-mono text-[10px] uppercase tracking-widest font-bold text-carbon-black py-4 px-8 rounded-full shadow-xl hover:-translate-y-0.5 active:translate-y-0 transition-all duration-300 disabled:opacity-40 disabled:hover:bg-ember-primary flex items-center gap-2 shine-sweep"
                  >
                    {isSubmitting ? (
                      <>
                        <span className="w-2 h-2 rounded-full border border-carbon-black border-t-transparent animate-spin" />
                        transmitting payload...
                      </>
                    ) : (
                      <>
                        Transmit blueprint
                        <ArrowRight className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </div>
              </form>

              {/* Submission success popup state */}
              {submitSuccess && (
                <div className="absolute inset-0 bg-carbon-black bg-opacity-95 backdrop-blur-md flex flex-col justify-center items-center p-6 text-center select-none z-50 animate-fade-in">
                  <div className="w-12 h-12 rounded-full bg-[#a0dbbf]/10 border border-[#a0dbbf]/30 flex items-center justify-center mb-4">
                    <Check className="w-6 h-6 text-[#a0dbbf] animate-bounce" />
                  </div>
                  <h3 className="font-serif text-2xl font-light text-bone-white mb-2">
                    Transmission complete.
                  </h3>
                  <p className="font-mono text-xs text-bone-white/50 leading-relaxed max-w-sm">
                    Payload [CON_PROPOSAL] received successfully. Jayesh Vasava will inspect your communication logs within 18 hours.
                  </p>
                  <button
                    onClick={() => setSubmitSuccess(false)}
                    className="mt-6 border border-bone-white/10 py-1.5 px-4 rounded-full font-mono text-[9px] uppercase tracking-wider text-bone-white hover:text-ember-primary hover:border-ember-primary transition-all"
                  >
                    Reset Form Space
                  </button>
                </div>
              )}
            </div>

            {/* RIGHT COLUMN: CHANNELS & DIRECT INFO */}
            <div className="lg:col-span-5 space-y-8 text-left text-sm md:text-base">
              
              {/* Direct email display block */}
              <div className="bg-graphite-dark p-6 rounded-xl border border-bone-white/10 space-y-1 bg-opacity-40 shadow-lg relative shine-sweep">
                <span className="font-mono text-[9px] text-bone-white/30 tracking-widest uppercase block">
                  Email Channel // Direct Link
                </span>
                <a 
                  href="mailto:jv172484@gmail.com"
                  className="font-serif text-xl sm:text-2xl text-bone-white tracking-snug hover:text-ember-primary transition-colors duration-300 block break-all font-light"
                >
                  jv172484@gmail.com
                </a>
              </div>

              {/* Status / Working stats metadata list */}
              <div className="font-mono text-xs text-bone-white/80 space-y-4 bg-graphite-dark/20 p-6 rounded-xl border border-bone-white/5">
                <div className="border-b border-bone-white/5 pb-2 flex justify-between gap-2">
                  <span className="text-bone-white/30">CURRENTLY:</span>
                  <span className="text-right">Working at PhysicsWallah</span>
                </div>
                
                <div className="border-b border-bone-white/5 pb-2 flex justify-between gap-2">
                  <span className="text-bone-white/30">ROLE:</span>
                  <span className="text-right">Content R&D Trainee</span>
                </div>

                <div className="border-b border-bone-white/5 pb-2 flex justify-between gap-2">
                  <span className="text-bone-white/30">EDUCATION:</span>
                  <span className="text-right text-nowrap">NSUT · Computer Science</span>
                </div>

                <div className="flex justify-between gap-2">
                  <span className="text-bone-white/30">STATUS:</span>
                  <span className="text-right text-[#a0dbbf] font-bold flex items-center gap-1.5 uppercase">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#a0dbbf] animate-ping" /> Open to collab
                  </span>
                </div>
              </div>

              {/* Social Channels list */}
              <div className="space-y-3 font-mono text-xs">
                <span className="text-[10px] text-bone-white/40 tracking-widest uppercase block font-bold border-b border-bone-white/5 pb-2 text-left">
                  Social Channels
                </span>
                
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { name: 'LinkedIn', user: 'in/jayesh-vasava', link: 'https://linkedin.com/in/jayesh-vasava', color: 'hover:text-[#0a66c2]' },
                    { name: 'GitHub', user: '@jayeshvasava', link: 'https://github.com/jayeshvasava', color: 'hover:text-ember-primary' },
                    { name: 'Instagram', user: '@jayeshvasava', link: 'https://instagram.com/jayeshvasava', color: 'hover:text-[#e1306c]' },
                    { name: 'WhatsApp', user: '+91 81682 94032', link: 'https://wa.me/918168294032', color: 'hover:text-[#25d366]' }
                  ].map((soc, idx) => (
                    <a
                      key={idx}
                      href={soc.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`flex flex-col items-start p-3 rounded-lg border border-bone-white/5 bg-graphite-dark/45 hover:border-ember-primary/20 transition-all ${soc.color}`}
                    >
                      <span className="text-[10px] font-bold text-bone-white/30 tracking-wider">
                        {soc.name}
                      </span>
                      <span className="text-[11px] text-bone-white/70 block truncate w-full pt-1">
                        {soc.user}
                      </span>
                    </a>
                  ))}
                </div>
              </div>

              {/* Branded Marketing Links */}
              <BrandedLinkHub />

            </div>

          </div>
        </section>


        {/* =========================================================================
            SECTION 6: FOOTER (Marquee, mega wordmark & back tags)
            ========================================================================= */}
        <section 
          id="footer"
          className="pt-16 pb-8 border-t border-bone-white/5 bg-carbon-black overflow-hidden select-none"
        >
          {/* Continuous scrolling text marquee */}
          <div className="border-y border-bone-white/5 py-4 flex overflow-hidden">
            <div className="animate-marquee-slow text-3xl sm:text-5xl font-serif font-extralight tracking-tight flex gap-8">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="flex gap-8 text-nowrap">
                  <span>Open to collaborations</span>
                  <span className="text-ember-primary italic font-serif">· Let's build something incredible</span>
                  <span>· Jayesh Vasava Index</span>
                  <span className="text-ember-primary font-bold">· 2024–2025</span>
                  <span>· NSUT CS Alumnus</span>
                  <span className="text-ember-primary italic font-serif">· PhysicsWallah Trainee</span>
                  <span className="text-bone-white/20">/ /</span>
                </div>
              ))}
            </div>
          </div>

          {/* Mega Parallax scaling wordmark */}
          <div className="py-12 flex justify-center items-center overflow-hidden">
            <h1 
              className="font-serif text-[12vw] font-bold tracking-tighter leading-none text-bone-white/5 hover:text-ember-primary/5 transition-colors duration-1000 select-none uppercase pointer-events-none"
              style={{ letterSpacing: '-0.04em' }}
            >
              Jayesh Vasava
            </h1>
          </div>

          {/* Bottom Bar items */}
          <div className="max-w-7xl mx-auto px-6 md:px-12 flex flex-col sm:flex-row justify-between items-center text-center gap-4 border-t border-bone-white/5 pt-6 font-mono text-[10px] text-bone-white/30">
            <div>
              © 2024–2025 Jayesh Vasava · All rights reserved
            </div>

            {/* PulsingCare indicator */}
            <div className="flex items-center gap-1 text-[#a0dbbf] font-bold bg-[#a0dbbf]/5 border border-[#a0dbbf]/10 rounded-full px-3 py-1 font-mono uppercase tracking-widest leading-none">
              <span className="w-1.5 h-1.5 rounded-full bg-[#a0dbbf] animate-pulse" />
              Built with care
            </div>

            <div className="flex gap-4">
              <a href="#about" onClick={(e) => { e.preventDefault(); scrollToSection('about'); }} className="hover:text-bone-white">Privacy</a>
              <a href="#contact" onClick={(e) => { e.preventDefault(); scrollToSection('contact'); }} className="hover:text-bone-white">Imprint</a>
              <button 
                onClick={() => scrollToSection('hero')}
                className="hover:text-ember-primary border-b border-dashed border-bone-white/10 hover:border-ember-primary uppercase font-bold tracking-wider"
              >
                Back to top ↑
              </button>
            </div>
          </div>
        </section>

      </main>

      {/* Floating Action HUD element in bottom margin (Cognitive trigger widget) */}
      <div 
        className="fixed bottom-6 right-6 z-100 hidden md:block"
        id="cognitive-hud-element"
      >
        <button
          onClick={() => setIsTerminalOpen(true)}
          className="group relative flex items-center justify-center p-3 rounded-full bg-graphite-dark border border-ember-primary/20 hover:border-ember-primary text-bone-white hover:text-ember-primary shadow-2xl transition-all duration-300 hover:scale-105 select-none"
          title="Wake Up Jayesh's AI Cognitive Brain Engine"
        >
          <div className="relative flex items-center justify-center">
            <span className="absolute w-12 h-12 rounded-full border border-ember-primary/10 animate-ping group-hover:block" />
            <span className="absolute w-8 h-8 rounded-full bg-ember-primary/20 blur-[2px] animate-pulse" />
            {/* Spinning network brain node */}
            <Terminal className="w-5 h-5 text-ember-primary relative z-10 animate-pulse" />
          </div>
          
          {/* Slider labeling trigger on hover */}
          <span className="max-w-0 overflow-hidden group-hover:max-w-[120px] group-hover:ml-2.5 font-mono text-[9px] uppercase tracking-widest font-bold text-bone-white/80 transition-all duration-500 whitespace-nowrap">
            JAYESH VASAVA CHART
          </span>
        </button>
      </div>

    </div>
  );
}
