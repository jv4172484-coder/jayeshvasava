import { Project, Service, TechStackRow, SkillItem } from './types';

// Jayesh Vasava's 4 core custom-pattern projects
export const PORTFOLIO_PROJECTS: Project[] = [
  {
    id: 'proj_forge',
    index: '01/04',
    year: '2025',
    category: 'Personal Workspace',
    title: 'Forge',
    description: 'An elegant, industrial-grade development workspace mimicking tactical visual grids. Features customized hotkeys, real-time code sandboxing, and telemetry log overlays.',
    url: 'https://forge-pink-seven.vercel.app/',
    accent: 'ember',
    patternType: 'grid',
    tags: ['Next.js', 'TypeScript', 'Tailwind v4', 'Framer Motion']
  },
  {
    id: 'proj_lawlab',
    index: '02/04',
    year: '2024',
    category: 'Legal Automation',
    title: 'LawLab',
    description: 'A cutting-edge client onboarding and automated legal documentation suite. Re-engineers standard procedural guidelines into highly structured workflows and contract generation.',
    url: 'https://lawlab-self.vercel.app/',
    accent: 'bone',
    patternType: 'lines',
    tags: ['React', 'Node.js', 'Express', 'Tailwind CSS']
  },
  {
    id: 'proj_resumeiq',
    index: '03/04',
    year: '2025',
    category: 'GenAI SaaS',
    title: 'ResumeIQ',
    description: 'An intelligent recruitment scanner utilizing real-time LLM feedback loops to grade compatibility, highlights keywords, and generates custom tailored cover letters.',
    url: 'https://resumeiq-harsh.vercel.app/',
    accent: 'red',
    patternType: 'circles',
    tags: ['Gemini API', 'React', 'Vite', 'Python Backend']
  },
  {
    id: 'proj_notch',
    index: '04/04',
    year: '2024',
    category: 'Designer Workflow',
    title: 'Notch',
    description: 'A minimalist workflow utility enabling visual designers to catalog project components, mock layouts, and coordinate global theme configurations securely.',
    url: 'https://notch-zeta.vercel.app/',
    accent: 'rust',
    patternType: 'mesh',
    tags: ['Next.js', 'Figma API', 'Zustand State', 'Tailwind']
  }
];

// Jayesh Vasava's 5 Core disciplines
export const CORE_SERVICES: Service[] = [
  {
    id: 'srv_1',
    index: '01',
    title: 'UI/UX Design',
    description: 'Designing clean, intuitive interfaces that prioritise user flow, hierarchy, and visual clarity with custom mathematical layout grids.',
    capabilities: ['Figma Design System', 'Prototyping', 'Interactions Map', 'Visual Rhythm', 'Tailored Typography']
  },
  {
    id: 'srv_2',
    index: '02',
    title: 'Front-end Development',
    description: 'Building highly responsive, blazing fast, performance-tuned web apps with state synchronization, React, TypeScript, and Tailwind.',
    capabilities: ['React & Vite', 'Next.js 14/15', 'Strict TypeScript', 'Framer Motion Anim', 'Lighthouse 100 Opt']
  },
  {
    id: 'srv_3',
    index: '03',
    title: 'GenAI Integration',
    description: 'Wiring large language models directly into real consumer products via Gemini, Claude, and OpenAI full-stack APIs.',
    capabilities: ['GoogleGenAI SDK', 'Context Engineering', 'Vector Embeddings', 'Model Orchestration', 'Security Layer Proxy']
  },
  {
    id: 'srv_4',
    index: '04',
    title: 'Prompt Engineering & LLM Automation',
    description: 'Crafting reliable prompts, automated workspace workflows, structured JSON schema response validations, and resilient agent logic.',
    capabilities: ['Few-Shot Prompts', 'Structured Schemas', 'API Orchestration', 'Workspace Loops', 'Reliability Guardrails']
  },
  {
    id: 'srv_5',
    index: '05',
    title: 'Data Analysis & Visualization',
    description: 'Exploring and rendering complex datasets with Python (Pandas, NumPy, Seaborn) and fully interactive Power BI visual dashboards.',
    capabilities: ['Python Dataframes', 'Static & Dynamic Charts', 'Interactive SVG Maps', 'Power BI Integration', 'Business Intelligence']
  }
];

// Tech stack categories
export const TECH_STOCKS_CATEGORIES: TechStackRow[] = [
  {
    category: 'Languages',
    items: ['Python', 'JavaScript', 'HTML5', 'CSS3', 'SQL (PostgreSQL)']
  },
  {
    category: 'Frameworks & libs',
    items: ['React 19', 'Tailwind v4', 'Pandas', 'NumPy', 'Scikit-learn', 'NLTK']
  },
  {
    category: 'Tools & platforms',
    items: ['Figma', 'Vercel', 'Git', 'GitHub', 'Power BI', 'Canva', 'Excel / Sheets']
  },
  {
    category: 'AI & GenAI',
    items: ['Gemini 3.1 Pro', 'Claude 3.5 Sonnet', 'OpenAI API', 'Prompt Engineering', 'Structured JSON Output']
  }
];

// Jayesh Vasava's skill progress indicators / meters
export const EXPERTISE_SKILLS: SkillItem[] = [
  { name: 'React / Next.js', percentage: 95 },
  { name: 'Tailwind CSS (inc. v4)', percentage: 98 },
  { name: 'JavaScript & TypeScript', percentage: 94 },
  { name: 'Python Data Science (Pandas/NumPy)', percentage: 88 },
  { name: 'UI/UX Design & Figma Systems', percentage: 92 },
  { name: 'Figma Prototyping', percentage: 90 },
  { name: 'GenAI/LLM Integration (APIs)', percentage: 94 },
  { name: 'Prompt Engineering & Workflow Automation', percentage: 96 }
];
