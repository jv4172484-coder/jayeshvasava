export interface Project {
  id: string;
  index: string;
  year: string;
  category: string;
  title: string;
  description: string;
  url: string;
  accent: string; /* 'ember' | 'bone' | 'red' | 'rust' */
  patternType: 'grid' | 'lines' | 'circles' | 'mesh';
  tags: string[];
}

export interface Service {
  id: string;
  index: string;
  title: string;
  description: string;
  capabilities: string[];
}

export interface TechStackRow {
  category: string;
  items: string[];
}

export interface SkillItem {
  name: string;
  percentage: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  reasoning?: string; /* Used to hold raw thinking blocks if returned by gemini-3.1-pro-preview */
  timestamp: string;
}
