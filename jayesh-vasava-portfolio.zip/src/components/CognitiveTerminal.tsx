import React, { useState, useRef, useEffect } from 'react';
import { Terminal, X, Minimize2, Maximize2, Send, BrainCircuit, Activity, RotateCcw } from 'lucide-react';
import { ChatMessage } from '../types';
import Markdown from 'react-markdown';

interface CognitiveTerminalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CognitiveTerminal({ isOpen, onClose }: CognitiveTerminalProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "msg_init",
      role: 'model',
      text: "Welcome to the jayesh vasava chart. I am Jayesh Vasava's virtual representation, powered by the Gemini 3.1 Pro engine. Ask me anything about my software architecture, UI/UX systems design, experience at PhysicsWallah, NSUT engineering syllabus, or challenge me on any high-level coding logic. Look inside my thought trace to evaluate my reasoning processes.\n\n🔒 **Privacy Protection Mode:** Under system privacy policies, data storage is completely disabled. Your questions are handled transiently and are never logged, cached, saved, or stored in the system.",
      timestamp: new Date().toLocaleTimeString(),
    }
  ]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  const [activeThought, setActiveThought] = useState<string | null>(null);
  
  // Tactical loading logs simulation to keep user visually engaged during high thinking processing
  const [loadingStep, setLoadingStep] = useState(0);
  const loadingLogs = [
    "&gt; initialising gemini-3.1-pro-preview cognitive model...",
    "&gt; configuring thinkingLevel: ThinkingLevel.HIGH",
    "&gt; analyzing system instructions and Jayesh's context variables...",
    "&gt; evaluating problem space and branching logical nodes...",
    "&gt; executing deep trace reasoning [no maxOutputTokens constraint]...",
    "&gt; compiling clean markdown syntax responses..."
  ];

  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading, loadingStep]);

  useEffect(() => {
    let interval: any;
    if (isLoading) {
      interval = setInterval(() => {
        setLoadingStep((prev) => (prev + 1) % loadingLogs.length);
      }, 2000);
    } else {
      setLoadingStep(0);
    }
    return () => clearInterval(interval);
  }, [isLoading]);

  // Clean chat log
  const handleReset = () => {
    setMessages([
      {
        id: "msg_init_" + Date.now(),
        role: 'model',
        text: "Welcome to the jayesh vasava chart. Ask me anything about my software architecture, UI/UX systems design, experience at PhysicsWallah, NSUT engineering syllabus, or challenge me on any high-level coding logic.\n\n🔒 **Privacy Protection Mode:** Data storage is completely disabled. No questions or answers are saved.",
        timestamp: new Date().toLocaleTimeString(),
      }
    ]);
    setActiveThought(null);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: "msg_" + Date.now(),
      role: 'user',
      text: inputText,
      timestamp: new Date().toLocaleTimeString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText("");
    setIsLoading(true);

    try {
      // Build brief chat history to keep model contextual
      const historyPayload = messages
        .filter((m) => m.id !== "msg_init" && !m.id.startsWith("msg_init_"))
        .slice(-6)
        .map((m) => ({
          role: m.role,
          text: m.text,
        }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: userMsg.text,
          history: historyPayload,
        }),
      });

      if (!res.ok) {
        throw new Error("Terminal network connection unstable.");
      }

      const data = await res.json();

      const modelMsg: ChatMessage = {
        id: "msg_model_" + Date.now(),
        role: 'model',
        text: data.text || "Cognitive request completed but returned empty response.",
        reasoning: data.reasoning || "",
        timestamp: new Date().toLocaleTimeString(),
      };

      setMessages((prev) => [...prev, modelMsg]);
      
      // If thinking logs occurred, automatically expand or point to active thought
      if (data.reasoning) {
        setActiveThought(data.reasoning);
      }
    } catch (err: any) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: "msg_err_" + Date.now(),
          role: 'model',
          text: `[SYSTEM_ALERT] Failed to retrieve cognitive intelligence. Reason: ${err.message || 'Gemini server failure'}. Please make sure your GEMINI_API_KEY is configured correctly.`,
          timestamp: new Date().toLocaleTimeString(),
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      className={`fixed top-0 right-0 h-full z-150 flex flex-col bg-carbon-black border-l border-bone-white/10 text-bone-white transition-all duration-500 ease-in-out shadow-2xl ${
        isMaximized ? 'w-full md:w-[75vw] lg:w-[60vw]' : 'w-full md:w-[480px] lg:w-[420px]'
      }`}
      id="cognitive-ai-terminal"
    >
      {/* 1. Header Bar styled like industrial terminal */}
      <div className="flex items-center justify-between px-4 py-3 bg-graphite-dark border-b border-bone-white/10 select-none">
        <div className="flex items-center gap-2">
          <div className="relative flex items-center justify-center">
            <span className="w-2.5 h-2.5 rounded-full bg-ember-primary/20 absolute animate-ping" />
            <span className="w-2.5 h-2.5 rounded-full bg-ember-primary relative" />
          </div>
          <span className="font-mono text-xs font-semibold uppercase tracking-wider text-bone-white/80 flex items-center gap-1.5">
            <BrainCircuit className="w-3.5 h-3.5 text-ember-primary animate-pulse" />
            JAYESH VASAVA CHART // STATELESS_SYS
          </span>
        </div>

        <div className="flex items-center gap-2 text-bone-white/40">
          <button 
            onClick={handleReset}
            className="p-1 hover:bg-bone-white/5 hover:text-ember-primary rounded transition-all"
            title="Reset Chat Session"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          
          <button 
            onClick={() => setIsMaximized(!isMaximized)}
            className="p-1 hover:bg-bone-white/5 hover:text-bone-white rounded transition-all hidden md:block"
            title={isMaximized ? "Minimize Terminal Pane" : "Maximize Terminal Pane"}
          >
            {isMaximized ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>

          <button 
            onClick={onClose}
            className="p-1 hover:bg-bone-white/5 hover:text-[#ef4444] rounded transition-all"
            title="Close Terminal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. Chat Readout screen */}
      <div 
        ref={scrollRef}
        className="flex-1 p-4 overflow-y-auto space-y-4 font-mono text-xs leading-relaxed max-h-[calc(100vh-130px)] grid-overlay"
      >
        <div className="text-[10px] text-bone-white/30 border-b border-bone-white/5 pb-2 uppercase tracking-tight flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <Activity className="w-3 h-3 text-ember-primary animate-pulse" />
            Channel: Client-to-Gemini // Status: ENCRYPTED
          </div>
          <div className="text-[9px] text-[#22c55e]/70 font-semibold tracking-widest uppercase flex items-center gap-1 mt-0.5">
            <span>● DATA STORAGE: DISABLED</span>
            <span className="text-bone-white/20">|</span>
            <span>NO QUESTIONS SAVED OR LOGGED</span>
          </div>
        </div>

        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={`flex flex-col space-y-1.5 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div className="flex items-center gap-1.5 text-[9px] text-bone-white/30">
              <span className={msg.role === 'user' ? 'text-ember-primary font-bold' : 'text-bone-white/60 font-semibold'}>
                {msg.role === 'user' ? 'USER_SYS' : 'JAYESH_VASAVA_CHART'}
              </span>
              <span>•</span>
              <span>{msg.timestamp}</span>
            </div>

            <div 
              className={`max-w-[85%] rounded-lg p-3 ${
                msg.role === 'user' 
                  ? 'bg-ember-primary/10 border border-ember-primary/20 text-bone-white' 
                  : 'bg-graphite-dark/80 border border-bone-white/5 text-bone-white/90'
              }`}
            >
              {msg.role === 'user' ? (
                <p className="whitespace-pre-wrap">{msg.text}</p>
              ) : (
                <div className="markdown-body">
                  <Markdown>{msg.text}</Markdown>
                </div>
              )}
            </div>

            {/* If the message lists a trace of reasoning/thought process */}
            {msg.reasoning && (
              <div className="w-[85%] mt-1 text-left">
                <button
                  onClick={() => setActiveThought(activeThought === msg.reasoning ? null : (msg.reasoning || null))}
                  className="px-2 py-1 text-[9px] font-mono border border-ember-primary/30 text-ember-primary hover:bg-ember-primary/10 rounded transition-all flex items-center gap-1.5 uppercase font-medium bg-carbon-black tracking-wider"
                >
                  <BrainCircuit className="w-3 h-3 text-ember-primary" />
                  {activeThought === msg.reasoning ? 'Hide Logical Thought Process' : 'Dissect AI Thought Process'}
                </button>
                
                {activeThought === msg.reasoning && (
                  <div className="mt-1.5 p-3 rounded-md bg-graphite-dark/50 border border-ember-primary/10 text-[10px] text-ember-light/60 font-mono leading-relaxed border-l-2 border-l-ember-primary relative overflow-hidden">
                    <div className="absolute top-1 right-2 text-[8px] text-ember-primary/30 uppercase tracking-widest select-none">
                      REASONING_CHAIN
                    </div>
                    <div className="whitespace-pre-wrap">{msg.reasoning}</div>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}

        {/* Dynamic Loading logs indicator */}
        {isLoading && (
          <div className="flex flex-col space-y-1.5 items-start">
            <div className="flex items-center gap-1.5 text-[9px] text-bone-white/30">
              <span className="text-bone-white/60 font-semibold">JAYESH_VASAVA_CHART</span>
              <span>•</span>
              <span className="animate-pulse">Thinking...</span>
            </div>
            
            <div className="w-[85%] rounded-lg p-3 bg-graphite-dark/80 border border-ember-primary/10 space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-ember-primary animate-ping" />
                <span className="text-[10px] font-semibold text-ember-primary tracking-widest uppercase">PROCESSOR_RUNNING</span>
              </div>
              <div className="font-mono text-[10px] text-ember-light/60 space-y-1">
                <p className="animate-pulse">{loadingLogs[loadingStep]}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 3. Input Console */}
      <form 
        onSubmit={handleSendMessage}
        className="p-3 bg-graphite-dark/90 border-t border-bone-white/10 flex gap-2 overflow-hidden"
      >
        <div className="flex-1 relative flex items-center">
          <Terminal className="absolute left-3 w-3.5 h-3.5 text-bone-white/30" />
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Type code query or prompt..."
            disabled={isLoading}
            className="w-full bg-carbon-black border border-bone-white/10 rounded-md py-2 pl-9 pr-3 text-xs font-mono text-bone-white placeholder-bone-white/20 focus:outline-none focus:border-ember-primary/40 focus:ring-0 disabled:opacity-50"
          />
        </div>
        <button
          type="submit"
          disabled={!inputText.trim() || isLoading}
          className="bg-ember-primary hover:bg-ember-primary/80 text-carbon-black p-2 rounded-md font-mono text-xs flex items-center justify-center gap-1 transition-all font-semibold disabled:opacity-40 disabled:hover:bg-ember-primary"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
}
