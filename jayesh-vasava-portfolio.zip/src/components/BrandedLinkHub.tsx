import React, { useState } from 'react';
import { Link, Copy, Check, ExternalLink, Globe } from 'lucide-react';

interface BrandedLink {
  id: string;
  name: string;
  slug: string;
  description: string;
  destination: string;
  type: string;
}

export default function BrandedLinkHub() {
  const [selectedDomain, setSelectedDomain] = useState('jayeshvasava.dev');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const availableDomains = [
    { value: 'jayeshvasava.dev', label: 'jayeshvasava.dev // PREMIER_DEV' },
    { value: 'jayeshvasava.com', label: 'jayeshvasava.com // EXECUTIVE' },
    { value: 'jayesh.link', label: 'jayesh.link // ULTRA_SHORT' },
    { value: 'vasava.design', label: 'vasava.design // SLICK_CREATIVE' }
  ];

  const brandedLinks: BrandedLink[] = [
    {
      id: 'lnk_cv',
      name: 'RESUME & CV',
      slug: '/resume',
      description: 'Redirects potential recruiters directly to my active profile/CV document.',
      destination: 'https://ais-dev-2ltsr4vrnzpsjircwzvvdo-884322019312.asia-east1.run.app/#about',
      type: 'RECRUITMENT'
    },
    {
      id: 'lnk_port',
      name: 'PRIMARY PORTFOLIO',
      slug: '/portfolio',
      description: 'The master link to this premium industrial cinematic workspace.',
      destination: 'https://jayeshvasava.dev',
      type: 'PORTFOLIO'
    },
    {
      id: 'lnk_forge',
      name: 'FORGE CRAFT UI',
      slug: '/forge',
      description: 'Direct workspace link to Forge (Industrial UI/UX environment implementation).',
      destination: 'https://forge-pink-seven.vercel.app/',
      type: 'FEATURED'
    },
    {
      id: 'lnk_lawlab',
      name: 'LAWLAB SUITE',
      slug: '/lawlab',
      description: 'Automated legal-tech utility workspace featuring systemic bones theme.',
      destination: 'https://lawlab-self.vercel.app/',
      type: 'FEATURED'
    },
    {
      id: 'lnk_resumeiq',
      name: 'RESUME IQ ENGINE',
      slug: '/resumeiq',
      description: 'GenAI screening & smart resume parser evaluation engine.',
      destination: 'https://resumeiq-harsh.vercel.app/',
      type: 'AI_AGENT'
    },
    {
      id: 'lnk_chat',
      name: 'STATELESS CHART AI',
      slug: '/chat',
      description: 'Launches the interactive stateless AI assistant engine directly.',
      destination: 'https://ais-dev-2ltsr4vrnzpsjircwzvvdo-884322019312.asia-east1.run.app/?terminal=open',
      type: 'AI_AGENT'
    }
  ];

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1800);
    }).catch(err => {
      console.error('Failed to copy: ', err);
    });
  };

  return (
    <div className="bg-graphite-dark border border-bone-white/10 rounded-xl p-6 bg-opacity-40 space-y-6 shadow-xl relative overflow-hidden text-left font-mono">
      {/* Decorative metal rivets */}
      <span className="absolute top-2 left-2 w-1.5 h-1.5 rounded-full bg-bone-white/5 border border-bone-white/15" />
      <span className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-bone-white/5 border border-bone-white/15" />
      <span className="absolute bottom-2 left-2 w-1.5 h-1.5 rounded-full bg-bone-white/5 border border-bone-white/15" />
      <span className="absolute bottom-2 right-2 w-1.5 h-1.5 rounded-full bg-bone-white/5 border border-bone-white/15" />

      {/* Header section with status light */}
      <div className="border-b border-bone-white/10 pb-4 space-y-1">
        <div className="flex items-center justify-between">
          <span className="text-[10px] text-ember-primary font-bold tracking-widest uppercase flex items-center gap-1.5">
            <Globe className="w-3 h-3 text-ember-primary animate-pulse" />
            JAYESH_VASAVA // MARKETING_REDIRECTS
          </span>
          <span className="text-[9px] text-green-400 font-bold tracking-wide uppercase px-1.5 py-0.5 bg-green-950/40 border border-green-800/30 rounded">
            ACTIVE
          </span>
        </div>
        <p className="font-serif text-[13px] font-light text-bone-white/70 italic leading-snug">
          High-performance, readable URL structures configured utilizing key brand marketing patterns.
        </p>
      </div>

      {/* Domain switcher layout */}
      <div className="space-y-2">
        <label className="text-[9px] text-bone-white/40 tracking-widest font-bold uppercase block">
          Select Marketing Brand Domain
        </label>
        <div className="relative">
          <select 
            value={selectedDomain}
            onChange={(e) => setSelectedDomain(e.target.value)}
            className="w-full bg-carbon-black text-xs text-bone-white/80 border border-bone-white/10 rounded-md p-2.5 focus:border-ember-primary focus:outline-none focus:ring-0 appearance-none font-mono cursor-pointer transition-all duration-300"
          >
            {availableDomains.map((dom) => (
              <option key={dom.value} value={dom.value} className="bg-carbon-black text-xs py-1">
                {dom.label}
              </option>
            ))}
          </select>
          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-bone-white/40 border-l border-bone-white/10">
            <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><path d="M70 90 l30 30 l30 -30 Z" /></svg>
          </div>
        </div>
      </div>

      {/* Links listings - bento cards */}
      <div className="space-y-3 pt-1">
        <span className="text-[9px] text-bone-white/40 tracking-widest font-bold uppercase block pb-1 border-b border-bone-white/5">
          Generated Link Payload
        </span>
        
        <div className="space-y-2.5 max-h-[290px] overflow-y-auto pr-1">
          {brandedLinks.map((link) => {
            const formattedUrl = `https://${selectedDomain}${link.slug}`;
            const isCopied = copiedId === link.id;

            return (
              <div 
                key={link.id} 
                className="bg-carbon-black/60 border border-bone-white/5 rounded-lg p-3 hover:border-ember-primary/20 transition-all duration-300 flex flex-col md:flex-row md:items-center justify-between gap-3 group relative overflow-hidden"
              >
                <div className="space-y-1 max-w-[85%] text-left">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[9px] text-ember-primary font-bold px-1.5 py-0.5 rounded bg-ember-primary/5 border border-ember-primary/10 tracking-wider">
                      {link.type}
                    </span>
                    <span className="text-[10px] font-bold text-bone-white/80 tracking-wide uppercase">
                      {link.name}
                    </span>
                  </div>
                  
                  <div className="text-[11px] text-bone-white/90 font-bold font-mono truncate hover:text-ember-primary select-all transition-colors duration-200">
                    {formattedUrl}
                  </div>
                  
                  <p className="text-[9px] text-bone-white/40 leading-relaxed font-light">
                    {link.description}
                  </p>
                </div>

                <div className="flex gap-2 self-end md:self-center">
                  {/* Action Copy Button */}
                  <button
                    onClick={() => handleCopy(link.id, formattedUrl)}
                    title="Copy Branded Link to Clipboard"
                    className={`p-2 rounded-md border flex items-center justify-center transition-all duration-300 cursor-pointer ${
                      isCopied 
                      ? 'bg-ember-primary/10 text-ember-primary border-ember-primary/35' 
                      : 'bg-graphite-dark text-bone-white/50 border-bone-white/5 hover:border-ember-primary/30 hover:text-bone-white'
                    }`}
                  >
                    {isCopied ? (
                      <Check className="w-3.5 h-3.5" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>

                  {/* Destination testing link */}
                  <a
                    href={link.destination}
                    target="_blank"
                    rel="noopener noreferrer"
                    title={`Test destination logic (${link.slug} -> destination)`}
                    className="p-2 rounded-md border border-bone-white/5 bg-graphite-dark text-bone-white/50 hover:border-ember-primary/30 hover:text-bone-white flex items-center justify-center transition-all duration-300"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Redirect deployment checklist */}
      <div className="bg-carbon-black/40 border border-bone-white/5 rounded-lg p-3 text-[10px] text-bone-white/40 space-y-2 select-none leading-relaxed">
        <span className="text-bone-white/60 font-bold uppercase tracking-widest block text-[9px]">
          SYS // METADATA REDIRECT MAP:
        </span>
        <p>
          Configure these <strong>301 Permanent Redirects</strong> or alias points inside your domain provider (GoDaddy, Namecheap, Vercel, or Netlify Redirect configs) to point seamlessly to target live pathways.
        </p>
      </div>
    </div>
  );
}
