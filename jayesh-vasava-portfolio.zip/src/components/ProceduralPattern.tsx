import { useEffect, useRef } from 'react';

interface ProceduralPatternProps {
  type: 'grid' | 'lines' | 'circles' | 'mesh';
  color: string; /* Hex color representation or a descriptive accent code */
}

export default function ProceduralPattern({ type, color }: ProceduralPatternProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = canvas.width = canvas.parentElement?.clientWidth || 300;
    let height = canvas.height = canvas.parentElement?.clientHeight || 200;

    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      width = canvas.width = entries[0].contentRect.width || 300;
      height = canvas.height = entries[0].contentRect.height || 200;
    });

    if (canvas.parentElement) {
      resizeObserver.observe(canvas.parentElement);
    }

    // Colors mapping based on project design palette details
    const colorMap: Record<string, string> = {
      ember: '#F37512',
      bone: '#F2F2EC',
      red: '#ef4444',
      rust: '#b45309',
    };

    const targetColor = colorMap[color] || '#F37512';
    let time = 0;

    function render() {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, width, height);
      time += 0.01;

      // Draw standard blueprint style backing grid
      ctx.strokeStyle = 'rgba(242, 242, 236, 0.012)';
      ctx.lineWidth = 1;
      const gridSize = 20;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Render custom pattern of the project card
      if (type === 'grid') {
        const step = 25;
        ctx.lineWidth = 0.8;
        for (let x = 10; x < width; x += step) {
          for (let y = 10; y < height; y += step) {
            const val = Math.sin(x * 0.01 + y * 0.01 + time) * 0.5 + 0.5;
            ctx.strokeStyle = `${targetColor}${Math.floor(val * 40).toString(16).padStart(2, '0')}`;
            ctx.beginPath();
            ctx.arc(x, y, 2 + val * 3, 0, Math.PI * 2);
            ctx.stroke();

            if (val > 0.8) {
              ctx.fillStyle = `${targetColor}${Math.floor(val * 110).toString(16).padStart(2, '0')}`;
              ctx.fill();
            }
          }
        }
      } 
      else if (type === 'lines') {
        ctx.strokeStyle = `${targetColor}1a`;
        ctx.lineWidth = 1;
        const lineCount = 12;
        for (let i = 0; i < lineCount; i++) {
          const shift = Math.sin(time + i * 0.4) * 20;
          ctx.beginPath();
          ctx.moveTo(0, (height / lineCount) * i + shift);
          ctx.lineTo(width, (height / lineCount) * i - shift);
          ctx.stroke();
        }

        // Add visual dots joining
        ctx.fillStyle = `${targetColor}80`;
        for (let i = 0; i < lineCount; i++) {
          const sx = (width / lineCount) * i;
          const sy = height / 2 + Math.sin(time * 2 + i * 0.5) * (height / 3);
          ctx.beginPath();
          ctx.arc(sx, sy, 3, 0, Math.PI * 2);
          ctx.fill();
        }
      } 
      else if (type === 'circles') {
        const cx = width / 2;
        const cy = height / 2;
        ctx.lineWidth = 0.5;

        for (let r = 20; r < Math.max(width, height) * 0.8; r += 24) {
          const osc = Math.sin(time * 1.5 - r * 0.02) * 5;
          ctx.strokeStyle = `${targetColor}${Math.floor((1 - r / (Math.max(width, height) * 0.8)) * 50).toString(16).padStart(2, '0')}`;
          ctx.beginPath();
          ctx.arc(cx, cy, r + osc, 0, Math.PI * 2);
          ctx.stroke();

          // Satellite dot orbiting on this circular ring
          const localAngle = time * (100 / r) + r;
          const sx = cx + Math.cos(localAngle) * (r + osc);
          const sy = cy + Math.sin(localAngle) * (r + osc);
          ctx.fillStyle = `${targetColor}b3`;
          ctx.beginPath();
          ctx.arc(sx, sy, 2.5, 0, Math.PI * 2);
          ctx.fill();
        }
      } 
      else if (type === 'mesh') {
        const cols = 5;
        const rows = 4;
        const pointsArray: Array<{ x: number; y: number; bx: number; by: number }> = [];

        for (let i = 0; i < cols; i++) {
          for (let j = 0; j < rows; j++) {
            const bx = (width / (cols - 1)) * i;
            const by = (height / (rows - 1)) * j;
            pointsArray.push({
              bx,
              by,
              x: bx + Math.sin(time + i * 3 + j) * 8,
              y: by + Math.cos(time + i * 2 + j * 4) * 8,
            });
          }
        }

        // Draw connections
        ctx.lineWidth = 0.5;
        ctx.strokeStyle = `${targetColor}26`;
        pointsArray.forEach((p, idx) => {
          pointsArray.forEach((other, otherIdx) => {
            const dist = Math.sqrt(Math.pow(p.x - other.x, 2) + Math.pow(p.y - other.y, 2));
            if (dist < 90 && idx !== otherIdx) {
              ctx.beginPath();
              ctx.moveTo(p.x, p.y);
              ctx.lineTo(other.x, other.y);
              ctx.stroke();
            }
          });

          // Nodes
          ctx.fillStyle = idx % 3 === 0 ? `${targetColor}cc` : 'rgba(242, 242, 236, 0.2)';
          ctx.beginPath();
          ctx.arc(p.x, p.y, idx % 3 === 0 ? 3 : 1.5, 0, Math.PI * 2);
          ctx.fill();
        });
      }

      animId = requestAnimationFrame(render);
    }

    render();

    return () => {
      cancelAnimationFrame(animId);
      if (canvas.parentElement) {
        resizeObserver.unobserve(canvas.parentElement);
      }
    };
  }, [type, color]);

  return (
    <div className="absolute inset-0 bg-carbon-black rounded-lg overflow-hidden z-0 border border-bone-white/5">
      {/* Background subtle mesh canvas */}
      <canvas ref={canvasRef} className="w-full h-full object-cover" />
      {/* Absolute dark overlay blend to ensure nice text legibility */}
      <div className="absolute inset-0 bg-gradient-to-t from-carbon-black via-carbon-black/60 to-transparent pointer-events-none" />
    </div>
  );
}
