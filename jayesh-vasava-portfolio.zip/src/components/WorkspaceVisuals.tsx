import { useEffect, useRef, useState } from 'react';

export default function WorkspaceVisuals() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [useFallbackVideo, setUseFallbackVideo] = useState(false);

  useEffect(() => {
    // Check if the user's transparent video file exists, otherwise we scale up canvas simulation intensity
    const testVideo = document.createElement('video');
    testVideo.src = '/public/hero-developer.webm';
    testVideo.addEventListener('error', () => {
      setUseFallbackVideo(true);
    });
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = canvas.width = 400;
    let height = canvas.height = 400;

    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const { width: w, height: h } = entries[0].contentRect;
      width = canvas.width = w || 400;
      height = canvas.height = h || 400;
    });

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    // Set up particles (Floating Dust & Satellites)
    const particleCount = useFallbackVideo ? 65 : 40;
    const particles: Array<{
      x: number;
      y: number;
      z: number;
      vx: number;
      vy: number;
      vz: number;
      size: number;
      color: string;
    }> = [];

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: (Math.random() - 0.5) * 300,
        y: (Math.random() - 0.5) * 300,
        z: Math.random() * 300 - 150,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        vz: (Math.random() - 0.5) * 0.3,
        size: Math.random() * 1.5 + 0.5,
        color: Math.random() > 0.6 ? '#F37512' : '#FBD5A5',
      });
    }

    // Interactive cursor coordinates inside canvas space
    let mouseX = 0;
    let mouseY = 0;
    let targetMouseX = 0;
    let targetMouseY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      targetMouseX = e.clientX - rect.left - width / 2;
      targetMouseY = e.clientY - rect.top - height / 2;
    };

    window.addEventListener('mousemove', handleMouseMove);

    // Orbital satellite lines
    let angleX = 0.002;
    let angleY = 0.003;

    function draw() {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, width, height);

      // Lerp mouse coordinates for custom smooth inertia parallax
      mouseX += (targetMouseX - mouseX) * 0.05;
      mouseY += (targetMouseY - mouseY) * 0.05;

      const fov = 250; // Camera field of view projection factor
      ctx.save();
      ctx.translate(width / 2, height / 2);

      // Draw subtle orbital rings (3D wireframes)
      ctx.strokeStyle = 'rgba(243, 117, 18, 0.07)';
      ctx.lineWidth = 1;
      
      // Orbit 1 inside projection
      ctx.beginPath();
      for (let theta = 0; theta <= Math.PI * 2; theta += 0.05) {
        // Simple rotation projection around X & Y axes + mouse parallax
        const rx = Math.cos(theta) * 110;
        const rz = Math.sin(theta) * 110;
        
        // Tilt the orbit ring slightly
        const rotY = rx * Math.cos(angleX * 4) - rz * Math.sin(angleX * 4);
        const rotZ = rx * Math.sin(angleX * 4) + rz * Math.cos(angleX * 4);
        
        const scale = fov / (fov + rotZ + (mouseY * 0.1));
        const px = (rotY + (mouseX * 0.12)) * scale;
        const py = (Math.sin(theta) * 35) * scale;

        if (theta === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.stroke();

      // Orbit 2
      ctx.strokeStyle = 'rgba(242, 242, 236, 0.04)';
      ctx.beginPath();
      for (let theta = 0; theta <= Math.PI * 2; theta += 0.05) {
        const rx = Math.cos(theta) * 150;
        const rz = Math.sin(theta) * 150;
        
        const rotY = rx * Math.cos(-angleY * 2) - rz * Math.sin(-angleY * 2);
        const rotZ = rx * Math.sin(-angleY * 2) + rz * Math.cos(-angleY * 2);
        
        const scale = fov / (fov + rotZ + (mouseY * 0.08));
        const px = (rotY + (mouseX * 0.08)) * scale;
        const py = (Math.sin(theta) * -60) * scale;

        if (theta === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.stroke();

      // Draw particles (3D to 2D projection)
      particles.forEach((p) => {
        // Slow particle translation physics
        p.x += p.vx;
        p.y += p.vy;
        p.z += p.vz;

        // Boundaries reset
        if (Math.abs(p.x) > 200) p.vx *= -1;
        if (Math.abs(p.y) > 200) p.vy *= -1;
        if (Math.abs(p.z) > 150) p.vz *= -1;

        // 3D Matrix Rotation (Subtle spinning camera coordinate system)
        const cosX = Math.cos(angleX);
        const sinX = Math.sin(angleX);
        const cosY = Math.cos(angleY);
        const sinY = Math.sin(angleY);

        // Y-axis rotation
        let x1 = p.x * cosY - p.z * sinY;
        let z1 = p.x * sinY + p.z * cosY;

        // X-axis rotation
        let y2 = p.y * cosX - z1 * sinX;
        let z2 = p.y * sinX + z1 * cosX;

        // Apply mouse inertia positioning parallax
        const finalX = x1 + (mouseX * 0.15);
        const finalY = y2 + (mouseY * 0.15);
        const finalZ = z2;

        const scale = fov / (fov + finalZ);
        const screenX = finalX * scale;
        const screenY = finalY * scale;

        // Depth-based transparency rendering
        const opacity = Math.max(0.08, Math.min(1, (fov - finalZ) / (fov * 1.5)));

        ctx.beginPath();
        ctx.fillStyle = p.color;
        ctx.globalAlpha = opacity;
        ctx.arc(screenX, screenY, p.size * scale, 0, Math.PI * 2);
        ctx.fill();

        // Connect near neighbors with technical mesh nodes
        particles.forEach((other) => {
          const dx = p.x - other.x;
          const dy = p.y - other.y;
          const dz = p.z - other.z;
          const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

          if (dist < 45) {
            // Project neighbor coordinates
            const otherX1 = other.x * cosY - other.z * sinY;
            const otherZ1 = other.x * sinY + other.z * cosY;
            const otherY2 = other.y * cosX - otherZ1 * sinX;
            const otherZ2 = other.y * sinX + otherZ1 * cosX;

            const otherFinalX = otherX1 + (mouseX * 0.15);
            const otherFinalY = otherY2 + (mouseY * 0.15);
            const otherFinalZ = otherZ2;

            const otherScale = fov / (fov + otherFinalZ);
            const otherScreenX = otherFinalX * otherScale;
            const otherScreenY = otherFinalY * otherScale;

            ctx.strokeStyle = `rgba(251, 213, 165, ${0.05 * (1 - dist / 45)})`;
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            ctx.moveTo(screenX, screenY);
            ctx.lineTo(otherScreenX, otherScreenY);
            ctx.stroke();
          }
        });
      });

      ctx.restore();
      ctx.globalAlpha = 1.0;

      animationFrameId = requestAnimationFrame(draw);
    }

    draw();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handleMouseMove);
      if (containerRef.current) {
        resizeObserver.unobserve(containerRef.current);
      }
    };
  }, [useFallbackVideo]);

  return (
    <div 
      ref={containerRef} 
      className="relative w-full h-full flex items-center justify-center overflow-hidden min-h-[380px]"
      id="workspace-visuals-container"
    >
      {/* 1. Behind Overlay Glowing Amber Orbs with Backdrop Blur */}
      <div className="absolute w-[220px] h-[220px] rounded-full bg-ember-primary/10 blur-[110px] animate-glow-pulse-1 pointer-events-none" />
      <div className="absolute w-[180px] h-[180px] rounded-full bg-ember-highlight/5 blur-[90px] animate-glow-pulse-2 pointer-events-none" />

      {/* 2. Three.js Equivalent Simulated Canvas (Orbit Satellites + Connected Particles) */}
      <canvas 
        ref={canvasRef} 
        className="absolute top-0 left-0 w-full h-full z-10 pointer-events-none"
      />

      {/* 3. Transparent Developer Video rendering directly or a fallback visual mock */}
      {!useFallbackVideo ? (
        <video
          className="absolute z-0 w-[95%] h-[95%] object-contain pointer-events-none opacity-40 mix-blend-normal"
          autoPlay
          loop
          muted
          playsInline
        >
          <source src="/public/hero-developer.webm" type="video/webm" />
          <source src="/public/hero-developer.mp4" type="video/mp4" />
        </video>
      ) : (
        /* Fallback coding dashboard inside luxurious glass cover */
        <div 
          className="relative z-0 w-[85%] max-w-[420px] aspect-[4/3] rounded-xl border border-bone-white/10 bg-graphite-dark/60 backdrop-blur-md p-4 flex flex-col justify-between font-mono text-[11px] text-bone-white/40 shadow-2xl overflow-hidden hover:border-ember-primary/20 transition-all duration-700 shine-sweep"
          id="mock-ide-fallback"
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-bone-white/10 pb-2">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-ember-primary/60 blur-[1px] animate-pulse" />
              <span className="text-bone-white/70 tracking-wider">JAYESH_WORKSPACE_SYS</span>
            </div>
            <div className="flex gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-bone-white/20" />
              <div className="w-1.5 h-1.5 rounded-full bg-bone-white/20" />
              <div className="w-1.5 h-1.5 rounded-full bg-bone-white/20" />
            </div>
          </div>

          {/* Typing simulation */}
          <div className="flex-1 py-3 text-left leading-relaxed text-bone-white/60 space-y-2 select-none overflow-y-auto max-h-[190px]">
            <p className="text-ember-primary font-medium tracking-tight">import {"{"} WebGLEngine, UICompiler {"}"} from 'jayesh-vasava';</p>
            <p className="text-bone-white/30 font-light">&gt; initialising 3d_workspace_model ...</p>
            <p className="text-bone-white/80 font-normal">
              const app = new WebGLEngine({"{"}<br/>
              &nbsp;&nbsp;element: "#creative-canvas",<br/>
              &nbsp;&nbsp;vibe: "FORGED_BUILD_INDUSTRIAL",<br/>
              &nbsp;&nbsp;location: "NSUT_ALUMNI",<br/>
              &nbsp;&nbsp;power: "GEMINI_COGNITION_CORE"<br/>
              {"}"});
            </p>
            <p className="text-[#a0dbbf] font-medium">&gt; compilations: SUCCESSFUL [100% Avg LightHouse]</p>
            <p className="text-bone-white/30 font-light">&gt; status: open_to_collaborations: true</p>
          </div>

          {/* Bottom stats tracking */}
          <div className="flex items-center justify-between border-t border-bone-white/10 pt-2 text-[9px] tracking-wider text-bone-white/30">
            <span>SYS_PORT: 3000</span>
            <span className="text-ember-primary">FPS: 60.00</span>
            <span>SHIPPED_PWINDEX: 2024–2025</span>
          </div>

          {/* Corner brackets detail */}
          <div className="absolute top-1 left-1 w-1.5 h-1.5 border-t border-l border-ember-primary/40" />
          <div className="absolute top-1 right-1 w-1.5 h-1.5 border-t border-r border-ember-primary/40" />
          <div className="absolute bottom-1 left-1 w-1.5 h-1.5 border-b border-l border-ember-primary/40" />
          <div className="absolute bottom-1 right-1 w-1.5 h-1.5 border-b border-r border-ember-primary/40" />
        </div>
      )}
    </div>
  );
}
