import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";

// Ensure environment variables are loaded
dotenv.config();

const app = express();
const PORT = 3000;

// Enable JSON bodies
app.use(express.json());

// Lazy-loaded Gemini Client Helper
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required. Please set it in the Settings panel.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// System Persona instructions for Jayesh Vasava's Portfolio Assistant
const SYSTEM_INSTRUCTION = `
You are the jayesh vasava chart (AI Assistant) representing Jayesh Vasava, a world-class Web Developer, UI-UX Designer, and Computer Science graduate from NSUT (Netaji Subhas University of Technology). 
Your tone is intellectual, refined, slightly technical, professional, yet deeply helpful and custom-tailored to Jayesh's aesthetic (cinematic, industrial, premium, thoughtful).

Key details about Jayesh:
- Role & Background: Computer Science graduate from NSUT. Currently working as a Content R&D Trainee at PhysicsWallah, where he helps ship highly interactive, real-time live learning products.
- Specialties: Advanced UI/UX, precise front-end engineering, full-stack state coordination, and GenAI production-level integrations.
- Creative Philosophy: "Crafting digital experiences. Designed end-to-end. Built with intention."

Jayesh's Featured Projects:
1. Forge (Personal) - live at https://forge-pink-seven.vercel.app/ (Industrial workspace UI/UX, grid visual pattern, ember theme)
2. LawLab (Personal) - live at https://lawlab-self.vercel.app/ (Legal tech automated suite, lines pattern, bone theme)
3. ResumeIQ (Personal · GenAI) - live at https://resumeiq-harsh.vercel.app/ (Resume screening & smart evaluation engine, circles pattern, deep red theme)
4. Notch (Personal · Design) - live at https://notch-zeta.vercel.app/ (Premium designer workflow/util, mesh pattern, rust theme)

Jayesh's Disciplines:
- 01. UI/UX Design - clean, intuitive layout systems that focus code architecture on user flow and visual harmony.
- 02. Front-end Development - ultra-responsive, high-performance web systems utilizing React, Vite, TS, and custom Tailwind setups.
- 03. GenAI Integration - wire LLM APIs (Gemini, Claude, OpenAI) into real production-ready interfaces.
- 04. Prompt Engineering & LLM Automation - reliable agent chains and flow logic.
- 05. Data Analysis & Visualization - Python (Pandas, NumPy, Seaborn) data models and Power BI business dashboards.

Rules of Engagement:
1. You represent Jayesh's engineering brain. When a user asks about Jayesh's resume, stack, coding style, or how to contact him (jv172484@gmail.com / NSUT / India), answer with pristine clarity.
2. If asked general complex coding, system architecture, or UI layout questions, leverage your HIGH-thinking intelligence (Gemini 3.1 Pro Preview) to give extremely elite, structured, and insightful answers.
3. Keep answers neatly formatted in Markdown (using bullet points and lists where readable).
4. Address yourself as "jayesh vasava chart // Jayesh's Virtual Brain".
5. CRITICAL PRIVACY RULE: Do not ask for, save, log, or store any personal data or user questions. Inform the user that data storage is disabled and that their questions are processed completely statelessly and not stored on any system or server database.
`.trim();

// API routes
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// Chat endpoint with High-Level Thinking
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Message parameter is required." });
    }

    const ai = getGeminiClient();

    // Map client-side history format to Gemini parts format if any
    const apiContents: any[] = [];
    
    // Add history from client
    if (history && Array.isArray(history)) {
      history.forEach((msg: any) => {
        apiContents.push({
          role: msg.role === "user" ? "user" : "model",
          parts: [{ text: msg.text }]
        });
      });
    }

    // Add current user prompt
    apiContents.push({
      role: "user",
      parts: [{ text: message }]
    });

    // Call the model with HIGH thinking level, falling back to gemini-3.5-flash if needed
    let response;
    let fallbackUsed = false;
    try {
      response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: apiContents,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          thinkingConfig: {
            thinkingLevel: ThinkingLevel.HIGH,
          },
        },
      });
    } catch (apiError: any) {
      console.warn("Primary gemini-3.1-pro-preview failed. Transitioning to fallback gemini-3.5-flash...", apiError);
      fallbackUsed = true;
      response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: apiContents,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
        },
      });
    }

    const text = response?.text || "";

    // Extract thoughts/reasoning from the candidate parts
    let reasoning = "";
    if (fallbackUsed) {
      reasoning = "> Primary model (gemini-3.1-pro-preview with HIGH thinking) exceeded quota limits or is unavailable in the current tier.\n\n> Successfully completed transaction via high-speed gemini-3.5-flash fallback engine [Thinking: MINIMAL].";
    } else {
      const parts = response?.candidates?.[0]?.content?.parts || [];
      for (const part of parts) {
        if (part.thought) {
          reasoning += part.text || "";
        }
      }
    }

    return res.json({
      text,
      reasoning,
    });
  } catch (error: any) {
    console.error("Gemini thinking API error:", error);
    return res.status(500).json({
      error: error.message || "Failed to process cognitive request.",
    });
  }
});

// Vite middleware integrated into Express
async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    // In dev, use Vite's dev server middleware
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // In production, serve the compiled static build
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    // Serve index.html for SPA routing
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[jayesh vasava chart] Server listening at http://localhost:${PORT}`);
  });
}

setupServer();
